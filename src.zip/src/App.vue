<template>
	<div id="app" class="clearfix" :class="{'oa_ecbao_cn' : oa_login}" v-loading.fullscreen.lock="fullscreenLoading">
		<div class="app_nav">
			<div class="app_nav_logo"></div>
			<div class="app_nav_access">
				<span @click="userMenusToggle = 0; $router.push('/');" v-bind:class="{active: userMenusToggle ==0}"><i class="iconfont" style="fontsize: 30px;">&#xe684;</i>协同办公</span>
				<span @click="ukeyPopShow" v-bind:class="{active: userMenusToggle==1}"><i class="iconfont" style="fontsize: 30px;">&#xe79c;</i>公司管理</span>
        		<span @click="userMenusToggle = 2;$router.push('/');" :class="{active: userMenusToggle==2}"><i class="iconfont" style="fontsize: 30px;">&#xe677;</i>招聘</span>
			</div>
			<div class="app_nav_msg">
				<el-dropdown trigger="hover" @command="logOut">
					<div class="el-dropdown-link">
						<span class="add_nav_msg_header" v-if="userData&&userData.fileInfo == null">{{userData.name != null?userData.name.slice(-2):"无名"}}</span>
						<span class="add_nav_msg_header" v-if="userData&&userData.fileInfo != null"><img :src="userData.fileInfo.url"></span>
						<span class="add_nav_msg_name" v-if="userData">{{userData.name}}</span>
						<span class="add_nav_msg_header" v-else="">无名</span>
					</div>
					<el-dropdown-menu slot="dropdown">
						<el-dropdown-item style="text-align: center;font-size:12px;">
							<router-link to="/personal">个人中心</router-link>
						</el-dropdown-item>
						<el-dropdown-item style="text-align: center;font-size:12px;" command="logOut">退出登录</el-dropdown-item>
					</el-dropdown-menu>
				</el-dropdown>
			</div>
		</div>
		<div class="app_right" v-bind:class="{smallbarClass: !smallbarShow}">
			<div class="app_right_box">
				<router-view keep-alive></router-view>
			</div>
		</div>
		<div class="app_left" v-bind:class="{smallbarClass: !smallbarShow}">
			<div class="app_left_smallbar" @click="smallbar"><i class="iconfont">&#xe620;</i></div>
			<el-menu :router="true" :default-active="defaultActive" :unique-opened="true" v-bind:class="{smallbarClass: !smallbarShow}" @select="selectMenu" :default-openeds="defaultOpeneds">
				<el-menu-item index="/index" v-show="userMenusToggle==0"><i class="iconfont">&#xe607;</i><span v-show="smallbarShow">首页</span></el-menu-item>
				<el-menu-item index="/manage/index" v-show="userMenusToggle==1"><i class="iconfont">&#xe607;</i><span v-show="smallbarShow">首页</span></el-menu-item>
				<!-- <el-menu-item index="/recruit/index" v-show="userMenusToggle==2"><i class="iconfont">&#xe607;</i><span v-show="smallbarShow">首页</span></el-menu-item> -->
				<el-submenu index="2" v-show="userMenusToggle==1 && userMenus.pay">
					<template slot="title"><i class="iconfont">&#xe60d;</i><span v-show="smallbarShow">薪资管理</span></template>
					<el-menu-item index="/manage/pay/payManage">工资管理</el-menu-item>
					<el-menu-item index="/manage/pay/payWages">发放工资条</el-menu-item>
					<el-menu-item index="/manage/pay/payRecord">发放记录</el-menu-item>
				</el-submenu>
				<el-submenu index="3" v-show="userMenusToggle==1 && userMenus.org">
					<template slot="title"><i class="iconfont">&#xe634;</i><span v-show="smallbarShow">组织人事</span></template>
					<el-menu-item index="/manage/org/orgMaintain">部门管理</el-menu-item>
					<el-menu-item index="/manage/org/orgDuty">职位管理</el-menu-item>
					<el-menu-item index="/manage/org/orgStaff">员工管理</el-menu-item>
				</el-submenu>
				<el-submenu index="5" v-show="userMenusToggle==1 && userMenus.att">
					<template slot="title"><i class="iconfont">&#xe6b6;</i><span v-show="smallbarShow">考勤管理</span></template>
					<el-menu-item index="/manage/attendance">考勤规则</el-menu-item>
					<el-menu-item index="/manage/attendanceTj">考勤统计</el-menu-item>
					<!--<el-menu-item index="/manage/attendance/abnormal">异常考勤</el-menu-item>-->
				</el-submenu>
				<el-submenu index="8" v-show="userMenusToggle==1 && userMenus.care">
					<template slot="title"><i class="iconfont">&#xe6aa;</i><span v-show="smallbarShow">公司文化</span></template>
					<el-menu-item index="/manage/usercare">员工关怀</el-menu-item>
				</el-submenu>
				<el-submenu index="4" v-show="userMenusToggle==1 && userMenus.jur">
					<template slot="title"><i class="iconfont">&#xe825;</i><span v-show="smallbarShow">权限管理</span></template>
					<el-menu-item index="/manage/jur/role">角色管理</el-menu-item>
					<el-menu-item index="/manage/jur/accredit">员工授权</el-menu-item>
				</el-submenu>
				<el-submenu index="6" v-show="userMenusToggle==0">
					<template slot="title"><i class="iconfont">&#xe604;</i><span v-show="smallbarShow">工作台</span></template>
					<el-menu-item index="/oa/report">工作汇报</el-menu-item>
					<el-menu-item index="/oa/approval">审批</el-menu-item>
					<el-menu-item index="/oa/task">任务</el-menu-item>
					<el-menu-item index="/oa/notice">公告</el-menu-item>
				</el-submenu>
				<el-submenu index="10" v-show="userMenusToggle==0">
					<template slot="title"><i class="iconfont">&#xe6b6;</i><span v-show="smallbarShow">考勤管理</span></template>
					<el-menu-item index="/attendance/my">我的考勤</el-menu-item>
				</el-submenu>

				<el-menu-item index="7" @click="routerPayStubs" v-show="userMenusToggle==0"><i class="iconfont">&#xe60d;</i><span v-show="smallbarShow">工资单</span></el-menu-item>
				<el-submenu index="11" v-show="!userMenusToggle">
					<template slot="title"><i class="iconfont">&#xe638;</i><span v-show="smallbarShow">面试管理</span></template>
					<el-menu-item index="/interviewInit">面试</el-menu-item>
					<el-menu-item index="/interviewHire">录用</el-menu-item>
					<el-menu-item index="/interviewPass">已入职</el-menu-item>
					<el-menu-item index="/interviewWeedOut">已淘汰</el-menu-item>
				</el-submenu>

				<el-submenu index="12" v-show="userMenusToggle==2">
          <template slot="title"><i class="iconfont">&#xe625;</i><span v-show="smallbarShow">人才库</span></template>
          <el-menu-item index="/talents/newResume">新简历库</el-menu-item>
          <el-menu-item index="/talents/alternative">备选库</el-menu-item>
          <el-menu-item index="/talents/library">面试库</el-menu-item>
					<el-menu-item index="/pool/talentpool">录取库</el-menu-item>
          <el-menu-item index="/talents/enterprise">企业人才库</el-menu-item>
        </el-submenu>

        <el-submenu index="13" v-show="userMenusToggle==2">
          <template slot="title"><i class="iconfont">&#xe6b3;</i><span v-show="smallbarShow">职位管理</span></template>
          <el-menu-item index="/recruit/list">职位列表</el-menu-item>
          <el-menu-item index="/recruit/post">职位发布</el-menu-item>
        </el-submenu>

        <el-submenu index="14" v-show="userMenusToggle==2">
          <template slot="title"><i class="iconfont">&#xe637;</i><span v-show="smallbarShow">微招聘</span></template>
          <el-menu-item index="/s_recruit">微招聘</el-menu-item>
        </el-submenu>

				<el-submenu index="15" v-show="userMenusToggle==2">
          <template slot="title"><i class="iconfont">&#xe63c;</i><span v-show="smallbarShow">设置</span></template>
          <el-menu-item index="/interviewSet">招聘设置</el-menu-item>
          <el-menu-item index="/employset">录用设置</el-menu-item>
        </el-submenu>

			</el-menu>
		</div>
		<el-dialog title="没有U盾提示" v-model="ukeyPop" size="tiny" v-if="ukeyPopNum == 0" class="ukey_pop">
			<p>如果您未插入爱聚U盾，请先插入U盾。</p>
			<p>如果您未安装爱聚U盾驱动，请点击<a href="https://hr.ecbao.cn/USBinstall/SetUpAll.exe">安装驱动</a>。</p>
			<p>如果您没有U盾，请联系我们。</p>
			<p>电话：0571-89935939 QQ：800036070</p>
			<span slot="footer" class="dialog-footer">
				<el-button @click="ukeyPop = false;">取消</el-button>
				<el-button type="primary" @click="ukeyPopNum = 1">遇到问题</el-button>
			</span>
		</el-dialog>
		<el-dialog title="遇到问题" v-model="ukeyPop" size="tiny" v-if="ukeyPopNum == 1" class="ukey_pop">
			<p>1、查看在设备管理器中是否存在该设备。（我的电脑->属性->硬件->设备管理器）</p>
			<p>2、请将爱聚U盾插入其他电脑进行测试，确认U盾是否正常。</p>
			<p>3、请确认爱聚U盾是否和账号对应。</p>
			<p>4、请确认爱聚U盾是否被液体浸湿，在使用时一定要注意防水及防潮。</p>
			<p>5、如插入爱聚U盾后网站无法识别，请确认电脑是否安装控件。</p>
			<p>6、电脑应该有良好的接地，如果接地不良，当有漏电就有可能使U盾损坏。</p>
			<p>如果您在使用过程中遇到了什么问题，您可以联系我们的售后人员。</p>
			<p>联系电话：0571-89935939 联系QQ：800036070</p>
			<span slot="footer" class="dialog-footer">
				<el-button @click="ukeyPop = false;">取消</el-button>
			</span>
		</el-dialog>
		<el-dialog title="U盾需要激活" v-model="ukeyPop" size="tiny" v-if="ukeyPopNum == 2">
			<p>您的U盾需要激活</p>
			<span slot="footer" class="dialog-footer">
				<el-button @click="ukeyPop = false;">取消</el-button>
				<el-button type="primary" @click="ukeyPopNum = 3">激活</el-button>
			</span>
		</el-dialog>
		<el-dialog title="确认激活页面" v-model="ukeyPop" size="tiny" v-if="ukeyPopNum == 3">
			<el-form label-width="100px" :model="ukeyActiveForm" :rules="ukeyActiveRules" ref="ukeyActiveForm">
				<el-form-item label="u盾序列号" prop="listkey">
					<el-input v-model="ukeyActiveForm.listkey"></el-input>
				</el-form-item>
				<el-form-item label="u盾激活码" prop="cdkey">
					<el-input v-model="ukeyActiveForm.cdkey"></el-input>
				</el-form-item>
			</el-form>
			<span slot="footer" class="dialog-footer">
				<el-button @click="ukeyPop = false;">取消</el-button>
				<el-button type="primary" @click="ukeyActiveSubmit('ukeyActiveForm')">确认</el-button>
			</span>
		</el-dialog>
		<el-dialog title="两次密码确认" v-model="ukeyPop" size="tiny" v-if="ukeyPopNum == 4">
			<el-form label-width="130px" :model="ukeyPasswordForm" :rules="ukeyPasswordRules" ref="ukeyPasswordForm">
				<el-form-item label="请输入密码" prop="password">
					<el-input type="password" v-model="ukeyPasswordForm.password"></el-input>
				</el-form-item>
				<el-form-item label="请再次输入密码" prop="againPassword">
					<el-input type="password" v-model="ukeyPasswordForm.againPassword"></el-input>
				</el-form-item>
			</el-form>
			<span slot="footer" class="dialog-footer">
				<el-button @click="ukeyPop = false;">取消</el-button>
				<el-button type="primary" @click="ukeyPasswordEdit('ukeyPasswordForm')">确认</el-button>
			</span>
		</el-dialog>
		<el-dialog title="密码验证" v-model="ukeyPop" size="tiny" v-if="ukeyPopNum == 5">
			<el-form label-width="130px" :model="ukeyValidateForm" :rules="ukeyValidateRules" ref="ukeyValidateForm">
				<el-form-item label="请输入U盾密码" prop="validate">
					<el-input type="password" v-model="ukeyValidateForm.validate"></el-input>
				</el-form-item>

			</el-form>
			<span slot="footer" class="dialog-footer">
				<el-button @click="ukeyPop = false;">取消</el-button>
				<el-button type="primary" @click="ukeyPasswordSubmit('ukeyValidateForm')">确认</el-button>
			</span>
		</el-dialog>

		<!--新增二级密码-->
		<el-dialog title="设置二级密码" v-model="ukeyPop" size="tiny" v-if="ukeyPopNum == 6">
			<el-form label-width="140px" :model="twoPasswordForm" :rules="twoPasswordRules" ref="twoPasswordForm">
				<el-form-item label="请输入密码" prop="password">
					<el-input type="password" v-model="twoPasswordForm.password"></el-input>
				</el-form-item>
				<el-form-item label="请再次输入密码" prop="againPassword">
					<el-input type="password" v-model="twoPasswordForm.againPassword"></el-input>
				</el-form-item>
			</el-form>
			<span slot="footer" class="dialog-footer">
				<el-button @click="ukeyPop = false;">取消</el-button>
				<el-button type="primary" @click="twoPasswordSubmit('twoPasswordForm')">确认</el-button>
			</span>
		</el-dialog>
		<!--验证二级密码-->
		<el-dialog title="验证二级密码" v-model="ukeyPop" size="tiny" v-if="ukeyPopNum == 7">
			<el-form label-width="130px" :model="twoValidateForm" :rules="twoValidateRules" ref="twoValidateForm">
				<el-form-item label="请输入密码" prop="password">
					<el-input type="password" v-model="twoValidateForm.password"></el-input>
				</el-form-item>
			</el-form>
			<span slot="footer" class="dialog-footer">
				<el-button @click="ukeyPop = false;">取消</el-button>
				<el-button type="primary" @click="ukeyPop = true; ukeyPopNum = 8;">忘记密码</el-button>
				<el-button type="primary" @click="twoPasswordValidate('twoValidateForm')">确认</el-button>
			</span>
		</el-dialog>
		<!--手机验证-->
		<el-dialog title="验证手机" v-model="ukeyPop" size="tiny" v-if="ukeyPopNum == 8">
			<el-form label-width="130px" :model="twoPhoneForm" :rules="twoPhoneRules" ref="twoPhoneForm">
				<el-form-item label="请输入手机号码" prop="phone">
					<el-input v-model="twoPhoneForm.phone"></el-input>
				</el-form-item>
				<el-form-item label="请输入验证码" prop="validate">
					<el-input v-model="twoPhoneForm.validate" style="margin-bottom: 20px;"></el-input>
					<el-button type="" @click="twoPhoneNote" v-text="payStubsResetBtnName" :disabled="disabled"></el-button>
				</el-form-item>

			</el-form>
			<span slot="footer" class="dialog-footer">
				<el-button @click="ukeyPop = false;">取消</el-button>
				<el-button type="primary" @click="twoPhoneValidate('twoPhoneForm')">确认</el-button>
			</span>
		</el-dialog>


	</div>
</template>

<script>
	import Style from 'style/main.css';// 公共样式文件
	import Util from 'script/util.js';//公共方法
	import { load, login_onclick } from 'script/ukey.js';//公共方法


	export default {
		name: 'app',
		data() {
			return {
				userData: {},
				ukeyPop: false,
				ukeyPopNum: 0,

				ukeyActiveForm: {
					listkey: '',
					cdkey: '',
				},
				ukeyActiveRules: {
					listkey: [{ required: true, message: '请输入序列号' }],
					cdkey: [{ required: true, message: '请输入激活码' }],
				},

				ukeyPasswordForm: {
					password: '',
					againPassword: '',
				},
				ukeyPasswordRules: {
					password: [{ required: true, message: '请输入密码' }, { pattern: /^\d{6}$/, message: '只能输入6位数字' }],
					againPassword: [{ required: true, message: '请再次输入密码' }, { pattern: /^\d{6}$/, message: '只能输入6位数字' }],
				},

				ukeyValidateForm: {
					validate: '',
				},
				ukeyValidateRules: {
					validate: [{ required: true, message: '请输入密码' }],
				},

				ukeyId: '',

				// 权限控制
				userMenus: {
					org: false,
					pay: false,
					jur: false,
					att: false,
					care:false,
					zhaopin:false,
					interview: false,
				},
				userMenusToggle: 0,

				twoPasswordStateData: false,

				twoPasswordForm: {
					password: '',
					againPassword: '',
				},
				twoPasswordRules: {
					password: [{ required: true, message: '请输入密码' }, { pattern: /^\d{4}$/, message: '只能输入4位数字' }],
					againPassword: [{ required: true, message: '请再次输入密码' }, { pattern: /^\d{4}$/, message: '只能输入4位数字' }],
				},
				twoValidateForm: {
					password: '',
				},
				twoValidateRules: {
					password: [{ required: true, message: '请输入密码' }],
				},
				twoPhoneForm: {
					phone: '',
					validate: '',
				},
				twoPhoneRules: {
					phone: [{ required: true, message: '请输入手机号' }, { pattern: /^\d{0,11}$/, message: '只能输入最多11位数字' }],
					validate: [{ required: true, message: '请输入验证码' }],
				},
				payStubsResetBtnName: '获取验证码',
				disabled: false,
				oa_login: false,
				fullscreenLoading: false,

				defaultActive: "",
				defaultOpeneds: [],
				smallbarShow: true,
			}
		},
		mounted: function () {
			this.userAjax();
			this.oaLoginShow();
			load();
			this.$nextTick(function () {
				console.log(window.location.hash.substring(1))
				this.defaultActive = window.location.hash.substring(1)
				if (window.location.hash.substring(2, 8) == 'manage') {
					this.userMenusToggle = 1;
				}
			})
		},
		methods: {
			selectMenu: function (index,indexpath){
				console.log(index,indexpath)
				if(!this.smallbarShow){
					this.defaultOpeneds = [];
				}
			},
			smallbar: function () {
				this.smallbarShow =! this.smallbarShow
				if(!this.smallbarShow){
					this.defaultOpeneds = [];
				}
			},
			userAjax: function () {
				var self = this;
				var method = 'user/getUser',
					param = JSON.stringify({
					}),
					succeed = function (res) {
						self.userData = res.data.data;
						self.userNavAjax()
						self.twoPasswordState();
						astart_setLog(res.data.data.companyId,res.data.data.id)//scrm统计埋点
					};
				this.$http(method, param, succeed);
			},
			userNavAjax: function () {
				var self = this;
				var method = 'permissionManage/getUserMenusByAjuc',
					param = JSON.stringify({
						"companyId": self.userData.companyId,
						"loginUserId": self.userData.id,
					}),
					succeed = function (res) {
						var arr = res.data.data.userMenus
						if (arr.length > 0) {
							for (var i = 0; i < arr.length; i++) {
								if (arr[i].name == "组织人事") {
									self.userMenus.org = true;
								}
								if (arr[i].name == "权限管理") {
									self.userMenus.jur = true;
								}
								if (arr[i].name == "薪资管理") {
									self.userMenus.pay = true;
								}
								if (arr[i].name == "考勤管理") {
									self.userMenus.att = true;
								}
								if (arr[i].name == "公司文化"){
									self.userMenus.care = true;
								}
								if(arr[i].name == '招聘管理'){
									self.userMenus.zhaopin=true;
								}
								if(arr[i].name == '面试管理'){
									self.userMenus.interview=true;
								}
							}
						}
					};
				this.$http(method, param, succeed);
			},
			// u盾状态判断
			ukeyPopShow: function () {
				if(this.userData&&this.userData.moreThan30){
					if (Util.ukeyNo) {
						this.userMenusToggle = 1;
						this.$router.push('/');
					} else {
						this.ukeyMethods();
					}
				}else{
					this.userMenusToggle = 1;
					this.$router.push('/');
				}
			},
			oaLoginShow: function () {
				var self = this;
				try {
					if (top.location.host == "oa.ecbao.cn") {
						self.oa_login = true;
					} else {
						self.oa_login = false;
					}
				} catch (error) {
					self.oa_login = true;
				}
				if (location.href == "https://hr.ecbao.cn/dist/#/?company") {
					self.userMenusToggle = 1;
				}
			},
			ukeyMethods: function () {
				var self = this;
				login_onclick(function (bConnect, ukeyid) {
					// 是否正常连接
					if (bConnect == 1 && ukeyid) {
						console.log(ukeyid)
						self.ukeyId = ukeyid;
						var method = 'usbCheck/userCheckActivation',
							param = JSON.stringify({
								"userStatus": 0,
								"lockId": ukeyid,
							}),
							succeed = function (res) {
								switch (res.data.data.code) {
									case '0':
										self.ukeyPopNum = 5;
										self.ukeyPop = true;
										break;
									case '1':
										self.ukeyPopNum = 2;
										self.ukeyPop = true;
										break;
									case '2':
										self.ukeyPopNum = 4;
										self.ukeyPop = true;
										break;
									default:
								};
							}
						self.$http(method, param, succeed);
					} else {
						console.log('未正常连接')
						self.ukeyPopNum = 0;
						self.ukeyPop = true;
					}
				})
			},
			// u盾激活
			ukeyActiveSubmit: function formName(formName) {
				var self = this;
				self.$refs[formName].validate((valid) => {
					if (valid) {
						var method = 'usbCheck/userActivationUSBKey',
							param = JSON.stringify({
								"serialNumber": self.ukeyActiveForm.listkey,
								"activationCode": self.ukeyActiveForm.cdkey,
								"userStatus": 0,
								"lockId": self.ukeyId,
							}),
							succeed = function (res) {
								self.$message({
									message: 'u盾激活成功!',
									type: 'success'
								});
								self.ukeyPopNum = 4;
								self.ukeyPop = true;
								self.$refs[formName].resetFields();
							};
						this.$http(method, param, succeed);
					}
				});
			},
			// u盾密码设置
			ukeyPasswordEdit: function (formName) {
				var self = this;
				if (self.ukeyPasswordForm.password != self.ukeyPasswordForm.againPassword) {
					self.$message({
						message: '二次密码不一致',
						type: 'warning'
					});
					return false;
				}

				self.$refs[formName].validate((valid) => {
					if (valid) {
						var method = 'usbCheck/userActivationSecondPassword',
							param = JSON.stringify({
								"secondPassword": self.ukeyPasswordForm.password,
								"userStatus": 0
							}),
							succeed = function (res) {
								self.$message({
									message: 'u盾密码设置成功!',
									type: 'success'
								});
								self.ukeyPopNum = 5;
								self.ukeyPop = true;
								self.$refs[formName].resetFields();
							};
						this.$http(method, param, succeed);
					}
				});
			},
			// u盾密码验证
			ukeyPasswordSubmit: function (formName) {
				var self = this;
				self.$refs[formName].validate((valid) => {
					if (valid) {
						var method = 'usbCheck/userCheckSecondPassword',
							param = JSON.stringify({
								"secondPassword": self.ukeyValidateForm.validate,
								"userStatus": 0
							}),
							succeed = function (res) {
								self.$message({
									message: 'u盾密码验证成功!',
									type: 'success'
								});
								self.ukeyPop = false;
								self.$refs[formName].resetFields();
								self.$router.push('/');
								self.userMenusToggle = 1;
							};
						this.$http(method, param, succeed);

					}
				});
			},

			// 二级密码状态判断
			twoPasswordState: function () {
				var self = this;
				var method = 'spwSalaryPay/toSetOrInputPwd',
					param = JSON.stringify({
						"loginUserId": self.userData.id,
					}),
					succeed = function (res) {
						self.twoPasswordStateData = res.data.data.isHaveSecondPwd == 1 ? false : true;
					};
				this.$http(method, param, succeed);
			},

			routerPayStubs: function () {
				if (this.twoPasswordStateData) {
					// this.$router.push('/pay/payStubs');
					// 设置二级密码
					this.ukeyPopNum = 6;
					this.ukeyPop = true;
				} else {
					// 验证二级密码
					this.ukeyPopNum = 7;
					this.ukeyPop = true;
				}
			},

			// 设置二级密码
			twoPasswordSubmit: function (formName) {
				var self = this;
				if (self.twoPasswordForm.password != self.twoPasswordForm.againPassword) {
					self.$message({
						message: '二次密码不一致',
						type: 'warning'
					});
					return false;
				}
				self.$refs[formName].validate((valid) => {
					if (valid) {
						var method = 'spwSalaryPay/updateSecondaryPwd',
							param = JSON.stringify({
								"id": self.userData.id,
								"secondaryPwd": self.twoPasswordForm.password,
							}),
							succeed = function (res) {
								self.$message({
									message: '二级密码设置成功!',
									type: 'success'
								});
								self.$refs[formName].resetFields();
								self.ukeyPopNum = 7;
								self.ukeyPop = true;
								self.twoPasswordStateData = false;
							};
						this.$http(method, param, succeed);

					}
				});
			},

			// 验证二级密码
			twoPasswordValidate: function (formName) {
				var self = this;
				self.$refs[formName].validate((valid) => {
					if (valid) {
						var method = 'spwSalaryPay/checkSecondPwd',
							param = JSON.stringify({
								"id": self.userData.id,
								"secondaryPwd": self.twoValidateForm.password,
							}),
							succeed = function (res) {
								self.$message({
									message: '二级密码验证成功!',
									type: 'success'
								});
								self.$refs[formName].resetFields();
								self.ukeyPop = false;
								self.ukeyPopNum = 0;
								self.$router.push('/pay/payStubs')
							};
						this.$http(method, param, succeed);

					}
				});
			},


			// 手机验证
			twoPhoneNote: function () {
				var self = this;
				if (self.twoPhoneForm.phone.length != 11) {
					self.$message({
						message: '请输入正确的手机号',
						type: 'warning'
					});
				} else {
					var method = 'spwSalaryPay/sendSMSOfCheckCode',
						param = JSON.stringify({
							"setPhone": self.twoPhoneForm.phone,
						}),
						succeed = function (res) {
							self.timer(60)
						};
					this.$http(method, param, succeed);
				}
			},
			timer: function (time) {
				var self = this;
				time--;
				if (time > 0) {
					console.log(time)
					self.disabled = true;
					setTimeout(function () {
						self.timer(time)
					}, 1000);
				} else {
					self.disabled = false;
				}
				self.payStubsResetBtnName = time > 0 ? time + 's 后重新获取' : '获取验证码';

			},
			twoPhoneValidate: function (formName) {
				var self = this;
				self.$refs[formName].validate((valid) => {
					if (valid) {
						var method = 'spwSalaryPay/validateCheckCode',
							param = JSON.stringify({
								"phone": self.twoPhoneForm.validate,
								"checkCode": self.twoPhoneForm.validate,
							}),
							succeed = function (res) {
								self.$refs[formName].resetFields();
								self.ukeyPopNum = 6;
								self.ukeyPop = true;
							};
						this.$http(method, param, succeed);

					}
				});
			},
			logOut(command) {
				if (command != "logOut") {
					return
				}
				var self = this;
				var url = "https://hr.ecbao.cn/hrm/login.do";
				var method = "user/getUser";
				var param = JSON.stringify({
					"flag": 1
				});
				var sucessd = function (res) {
					top.location.href = "https://hr.ecbao.cn/login";
				};
				self.$sendHttp(url, method, param, sucessd);
			},
		}
	}
</script>
