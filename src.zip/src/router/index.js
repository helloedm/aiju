import Vue from 'vue'
import Router from 'vue-router'
import index from 'components/index'

// 薪资管理
import payManage from 'components/pay/payManage'
import payRecord from 'components/pay/payRecord'
import payWages from 'components/pay/payWages'
import payAdjust from 'components/pay/payAdjust'
import payStubs from 'components/pay/payStubs'

// 权限
import jurAccredit from 'components/jur/jurAccredit'
import jurRole from 'components/jur/jurRole'

// 工作台
import oa from 'components/oa/oaIndex'
import oaReport from 'components/oa/oaReport'
import oaApproval from 'components/oa/oaApproval'
import oaTask from 'components/oa/oaTask'
import oaNotice from 'components/oa/oaNotice'

// 组织人事
import orgMaintain from 'components/org/orgMaintain'
import orgStaff from 'components/org/orgStaff'
import orgDuty from 'components/org/orgDuty'

// 考勤管理
import attendance from 'components/attendance/attendance'
import attendanceTj from 'components/attendance/attendanceTj'
import myAttendance from 'components/attendance/myAttendance'
import abnormal from 'components/attendance/abnormal'

//个人中心
import personal from 'components/personal/personal'

//公司文化
import usercare from 'components/culture/usercare'
import gocare from 'components/culture/goCare'
import caredetail from 'components/culture/caredetail'
import carefenxiang from 'components/culture/carefenxiang'

// 状态
import nopower from 'components/status/nopower'

//招聘
import employset from 'components/employ/employset'
import pool from 'components/employ/pool'
import talentpool from 'components/employ/talentpool'
import gooffer from 'components/employ/gooffer'
import come from 'components/employ/comeposition'
import confirmjoin from 'components/employ/confirmjoin'

//面试
import interviewSet from "components/interview/set"
import talents from "components/interview/talents"
import newResume from "components/interview/newResume"
import notice from "components/interview/notice"
import alternative from "components/interview/alternative"
import library from "components/interview/library"
import hire from "components/interview/hire"
import enterprise from "components/interview/enterprise"
import rating from "components/interview/rating"
import evaluate from "components/interview/evaluate"

import interviewInit from "components/interview/init"
import interviewPass from "components/interview/pass"
import interviewWeedOut from "components/interview/weedout"
import interviewHire from "components/interview/hire"
import resume from "components/interview/resume"

//微招聘
import publishPosition from "components/recruit/publishPosition"
import publishList from "components/recruit/publishList"
import publishDetail from "components/recruit/publishDetail"
import sRecruit from 'components/s_recruit/s_recruit'


Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'index',
      component: index
    },
    {
      path: '/index',
      name: 'index',
      component: index
    },
    {
      path: '/manage/index',
      name: 'index',
      component: index
    },
    {
      path: '/recruit/index',
      name: 'index',
      component: index
    },
    {
      path: '/manage/pay/payManage',
      name: 'payManage',
      component: payManage
    },
    {
      path: '/manage/pay/payRecord',
      name: 'payRecord',
      component: payRecord
    },
    {
      path: '/manage/pay/payWages',
      name: 'payWages',
      component: payWages
    },
    {
      path: '/manage/pay/payAdjust',
      name: 'payAdjust',
      component: payAdjust
    },
    {
      path: '/pay/payStubs',
      name: 'payStubs',
      component: payStubs
    },
    {
      path:'/manage/org/orgMaintain',
      name:'orgMaintain',
      component:orgMaintain
    },
    {
      path: '/manage/org/orgStaff',
      name: 'orgStaff',
      component: orgStaff
    },
    {
      path:'/manage/org/orgDuty',
      name:'orgDuty',
      component:orgDuty
    },
    {
      path: '/manage/jur/Accredit',
      name: 'jurAccredit',
      component: jurAccredit
    },
    {
      path: '/manage/jur/role',
      name: 'jurRole',
      component: jurRole
    },
    {
      path: '/oa/report',
      name: 'oaReport',
      component: oaReport
    },
    {
      path: '/oa/approval',
      name: 'oaApproval',
      component: oaApproval
    },
    {
      path: '/oa/task',
      name: 'oaTask',
      component: oaTask
    },
    {
      path: '/oa/notice',
      name: 'oaNotice',
      component: oaNotice
    },
    {
      path:'/manage/attendance',
      name:'attendance',
      component:attendance
    },
    {
      path:'/manage/attendanceTj',
      name:'attendanceTj',
      component:attendanceTj
    },
    {
      path:'/personal',
      name:'personal',
      component:personal
    },
    {
      path:'/manage/usercare',
      name:'usercare',
      component:usercare
    },
    {
      path:'/manage/gocare',
      name:"gocare",
      component:gocare
    },
    {
      path:'/manage/caredetail',
      name:"caredetail",
      component:caredetail,
      params:{id:null}
    },
    {
      path:'/nopower',
      name:"nopower",
      component:nopower
    },
    {
      path:'/carefenxiang',
      name:"carefenxiang",
      component:carefenxiang
    },
    {
      path:"/attendance/my",
      name:'myAttendance',
      component:myAttendance
    },
    {
      path:'/manage/attendance/abnormal',
      name:'abnormal',
      component:abnormal
    },
    {
      path:'/employset',
      name:'employset',
      component:employset
    },
    {
      path:'/manage/pool',
      name:'pool',
      component:pool
    },
    {
      path:'/pool/talentpool',
      name:'talentpool',
      component:talentpool
    },
    {
      path:'/manage/gooffer',
      name:'gooffer',
      component:gooffer,
      params:{active:null,hireEmployerId:null}
    },
    {
      path:'/manage/come',
      name:'come',
      component:come
    },
    {
      path:'/manage/confirmjoin',
      name:'confirmjoin',
      component:confirmjoin,
      params:{hireEmployerId:null}
    },
    {
      path:'/interviewSet',
      name:'interviewSet',
      component:interviewSet
    },
    {

      path:'/manage/talents',
      name:"talents",
      component:talents
    },
    {
      path:'/talents/newResume',
      name:'newResume',
      component:newResume
    },
    {
      path:'/talents/alternative',
      name:'alternative',
      component:alternative
    },
    {
      path:'/talents/library',
      name:'library',
      component:library
    },
    {
      path:"/talents/hire",
      name:'hire',
      component:hire
    },
    {
      path:'/talents/enterprise',
      name:'enterprise',
      component:enterprise
    },
    {
      path:'/manage/notice',
      name:'notice',
      component:notice
    },
    {
      path:'/manage/rating',
      name:'rating',
      component:rating
    },
    {
      path:'/manage/evaluate',
      name:'evaluate',
      params:null,
      component:evaluate
    },
    {
      path:'/interviewInit',
      name:'interviewInit',
      component:interviewInit
    },
    {
      path:'/interviewPass',
      name:'interviewPass',
      component:interviewPass
    },
    {
      path:'/interviewWeedOut',
      name:'interviewWeedOut',
      component:interviewWeedOut
    },
    {
      path:'/interviewHire',
      name:'interviewHire',
      component:interviewHire
    },
    {
      path:'/resume',
      name:'resume',
      component:resume
    },
    {
      path:'/recruit/list',
      name:'publishList',
      component:publishList
    },
    {
      path:'/recruit/post',
      name:'publishPosition',
      component:publishPosition
    },
    {
      path:'/recruit/detail',
      name:'publishDetail',
      component:publishDetail
    },
    {
      path:'/s_recruit',
      name:'s_recruit',
      component:sRecruit
    }
  ]
})
