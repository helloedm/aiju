<template>
    <div id="talentpool">
        <div class="hrm_module">
            <div class="hrm_module_btn">
                <el-button type="primary" class="pool_fasongoffer" @click="goOffer('123','chongfa')">去发送offer</el-button>
            </div>
            <el-row :gutter="20" class="padding_top_20">
                <el-col :span="4" :offset="2"><ul class="talentpool_head_ul" @click="changetalentStatus(0)" :class="{'active':talentStatus==0}"><li>offer发送记录</li><li class="font_size_20">{{offerRecordsCount0}}</li></ul></el-col>
                <el-col :span="4"><ul class="talentpool_head_ul" @click="changetalentStatus(1)" :class="{'active':talentStatus==1}"><li>待发送offer</li><li class="font_size_20">{{offerRecordsCount1}}</li></ul></el-col>
                <el-col :span="4"><ul class="talentpool_head_ul" @click="changetalentStatus(2)" :class="{'active':talentStatus==2}"><li>待接收offer</li><li class="font_size_20">{{offerRecordsCount2}}</li></ul></el-col>
                <el-col :span="4"><ul class="talentpool_head_ul" @click="changetalentStatus(3)" :class="{'active':talentStatus==3}"><li>待入职</li><li class="font_size_20">{{offerRecordsCount3}}</li></ul></el-col>
                <el-col :span="4"><ul class="talentpool_head_ul" @click="changetalentStatus(4)" :class="{'active':talentStatus==4}"><li>offer放弃记录</li><li class="font_size_20">{{offerRecordsCount4}}</li></ul></el-col>
            </el-row>
            <div class="hrm_module_con" v-show="talentStatus==0">
                <el-table
                :data="offerRecordsList0"
                border
                style="width: 100%">
                <el-table-column
                type="index"
                label="序号"
                width="55">
                </el-table-column>
                <el-table-column
                prop="name"
                label="姓名"
                width="180">
                </el-table-column>
                <el-table-column
                prop="userDraw"
                label="类型">
                    <template scope="scope">
                        <div v-if="scope.row.userDraw==1">正式</div>
                        <div v-if="scope.row.userDraw==2">试用</div>
                        <div v-if="scope.row.userDraw==3">兼职</div>
                        <div v-if="scope.row.userDraw==4">实习</div>
                        <div v-if="scope.row.userDraw==5">劳务派遣</div>
                    </template>
                </el-table-column>
                <el-table-column
                prop="deptName"
                label="部门">
                </el-table-column>
                <el-table-column
                prop="positionName"
                label="职位">
                </el-table-column>
                <el-table-column
                prop="phone"
                label="手机号">
                </el-table-column>
                <el-table-column
                prop="createTime"
                label="创建日期">
                </el-table-column>
                <el-table-column
                label="offer状态">
                    <template scope="scope">
                        <span v-if="scope.row.joinStatus==1">待接收</span>
                        <span v-if="scope.row.joinStatus==2">待入职</span>
                        <span v-if="scope.row.joinStatus==3">入职</span>
                        <span v-if="scope.row.joinStatus==4">offer无效</span>
                        <span v-if="scope.row.joinStatus==5">放弃入职</span>
                    </template>
                </el-table-column>
                <el-table-column
                prop="senderName"
                label="发送人">
                </el-table-column>
                <el-table-column
                label="操作">
                <template scope="scope">
                    <el-button @click="previewOffer(scope.row.offerId)" type="text" size="small">查看offer</el-button>
                </template>
                </el-table-column>
            </el-table>
            <el-pagination
            class="margin_t_20"
            @size-change="changePageSize"
            @current-change="changePageNum"
            :current-page="page.pageNum"
            :page-sizes="[10, 20, 30, 40]"
            :page-size="page.pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="page.totalCount">
            </el-pagination>
        </div>
            <div class="hrm_module_con" v-show="talentStatus==1">
                <el-table
                :data="offerRecordsList1"
                border
                style="width: 100%">
                <el-table-column
                type="index"
                label="序号"
                width="55">
                </el-table-column>
                <el-table-column
                prop="name"
                label="姓名"
                width="180">
                </el-table-column>
                <el-table-column
                prop="userDraw"
                label="类型">
                    <template scope="scope">
                        <div v-if="scope.row.userDraw==1">正式</div>
                        <div v-if="scope.row.userDraw==2">试用</div>
                        <div v-if="scope.row.userDraw==3">兼职</div>
                        <div v-if="scope.row.userDraw==4">实习</div>
                        <div v-if="scope.row.userDraw==5">劳务派遣</div>
                    </template>
                </el-table-column>
                <el-table-column
                prop="deptName"
                label="部门">
                </el-table-column>
                <el-table-column
                prop="positionName"
                label="职位">
                </el-table-column>
                <el-table-column
                prop="phone"
                label="手机号">
                </el-table-column>
                <el-table-column
                prop="createTime"
                label="创建日期">
                </el-table-column>
                <el-table-column
                label="offer创建进程">
                    <template scope="scope">
                        <span v-if="scope.row.processStatus==1">未完成</span>
                        <span v-if="scope.row.processStatus==2">可发送</span>
                        <el-popover
                        ref="popover1"
                        placement="top-end"
                        width="200"
                        trigger="hover">
                        <dl class="popover_ul">
                            <dt class="popover_dt">
                                <div>{{scope.row.name}}</div>
                                <h1>{{scope.row.name}}</h1>
                                <h2>到岗日期:{{scope.row.joinDate}}</h2>
                            </dt>
                            <dd class="popover_dd1">offer创建进度</dd>
                            <dd class="popover_dd2">
                                <el-steps :space="50" direction="vertical" :active="scope.row.processStatus">
                                    <el-step title="候选人信息"></el-step>
                                    <el-step title="薪酬信息"></el-step>
                                    <el-step title="发送offer"></el-step>
                                </el-steps>
                            </dd>
                        </dl>
                        </el-popover>
                        <i class="el-icon-information" v-popover:popover1></i>
                    </template>
                </el-table-column>
                <el-table-column
                label="操作">
                <template scope="scope">
                    <el-button @click="goOffer(scope.row)" type="text" size="small" v-if="scope.row.processStatus==1">继续完善</el-button>
                    <el-button @click="goOffer(scope.row)" type="text" size="small" v-if="scope.row.processStatus==2">去发offer</el-button>
                    <el-button type="text" size="small" @click="deleOffer(scope.row)">删除</el-button>
                </template>
                </el-table-column>
            </el-table>
            <el-pagination
            class="margin_t_20"
            @size-change="changePageSize"
            @current-change="changePageNum"
            :current-page="page.pageNum"
            :page-sizes="[10, 20, 30, 40]"
            :page-size="page.pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="page.totalCount">
            </el-pagination>
        </div>
        <div class="hrm_module_con" v-show="talentStatus==2">
                <el-table
                :data="offerRecordsList2"
                border
                style="width: 100%">
                <el-table-column
                type="index"
                label="序号"
                width="55">
                </el-table-column>
                <el-table-column
                prop="name"
                label="姓名"
                width="180">
                </el-table-column>
                <el-table-column
                label="类型">
                    <template scope="scope">
                        <div v-if="scope.row.userDraw==1">正式</div>
                        <div v-if="scope.row.userDraw==2">试用</div>
                        <div v-if="scope.row.userDraw==3">兼职</div>
                        <div v-if="scope.row.userDraw==4">实习</div>
                        <div v-if="scope.row.userDraw==5">劳务派遣</div>
                    </template>
                </el-table-column>
                <el-table-column
                prop="deptName"
                label="部门">
                </el-table-column>
                <el-table-column
                prop="positionName"
                label="职位">
                </el-table-column>
                <el-table-column
                prop="phone"
                label="手机号">
                </el-table-column>
                <el-table-column
                prop="createTime"
                label="创建日期">
                </el-table-column>
                <el-table-column
                label="是否已读">
                    <template scope="scope">
                        <span v-if="scope.row.offerStatus==2">未读</span>
                        <span v-if="scope.row.offerStatus==3">已读</span>
                        <!--<i class="el-icon-information"></i>-->
                    </template>
                </el-table-column>
                <el-table-column
                label="操作">
                <template scope="scope">
                    <el-button  type="text" size="small" @click="giveup(scope.row.hireEmployerId)">候选人放弃</el-button>
                    <el-button type="text" size="small" @click="previewOffer(scope.row.offerId)">查看offer</el-button>
                </template>
                </el-table-column>
            </el-table>
            <el-pagination
            class="margin_t_20"
            @size-change="changePageSize"
            @current-change="changePageNum"
            :current-page="page.pageNum"
            :page-sizes="[10, 20, 30, 40]"
            :page-size="page.pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="page.totalCount">
            </el-pagination>
        </div>
        <div class="hrm_module_con" v-show="talentStatus==3">
                <el-table
                :data="offerRecordsList3"
                border
                style="width: 100%">
                <el-table-column
                type="index"
                label="序号"
                width="55">
                </el-table-column>
                <el-table-column
                prop="name"
                label="姓名"
                width="180">
                </el-table-column>
                <el-table-column
                label="类型">
                    <template scope="scope">
                        <div v-if="scope.row.userDraw==1">正式</div>
                        <div v-if="scope.row.userDraw==2">试用</div>
                        <div v-if="scope.row.userDraw==3">兼职</div>
                        <div v-if="scope.row.userDraw==4">实习</div>
                        <div v-if="scope.row.userDraw==5">劳务派遣</div>
                    </template>
                </el-table-column>
                <el-table-column
                prop="deptName"
                label="部门">
                </el-table-column>
                <el-table-column
                prop="positionName"
                label="职位">
                </el-table-column>
                <el-table-column
                prop="phone"
                label="手机号">
                </el-table-column>
                <el-table-column
                prop="joinDate"
                label="到岗日期">
                </el-table-column>
                <el-table-column
                label="入职准备">
                    <template scope="scope">
                        <span>未完成</span>
                        <el-popover
                        ref="popover1"
                        placement="top-end"
                        width="200"
                        trigger="hover">
                        <dl class="popover_ul">
                            <dt class="popover_dt">
                                <div>{{scope.row.name}}</div>
                                <h1>{{scope.row.name}}</h1>
                                <h2>到岗日期:{{scope.row.joinDate}}</h2>
                            </dt>
                            <dd class="popover_dd1">员工入职进度</dd>
                            <dd class="popover_dd2">
                                <el-steps :space="50" direction="vertical" :active="scope.row.proccessStatus">
                                    <el-step title="入职登记表填写"></el-step>
                                    <el-step title="确认员工信息"></el-step>
                                    <el-step title="入职材料"></el-step>
                                    <el-step title="确认到岗"></el-step>
                                </el-steps>
                            </dd>
                        </dl>
                        </el-popover>
                        <i class="el-icon-information" v-popover:popover1></i>
                    </template>
                </el-table-column>
                <el-table-column
                label="操作">
                <template scope="scope">
                    <el-button  type="text" size="small" @click="giveup(scope.row.hireEmployerId)">候选人放弃</el-button>
                    <el-button type="text" size="small" @click="previewOffer(scope.row.offerId)">查看offer</el-button>
                    <el-button type="text" size="small" @click="confirmJoin(scope.row)">确认到岗</el-button>
                </template>
                </el-table-column>
            </el-table>
            <el-pagination
            class="margin_t_20"
            @size-change="changePageSize"
            @current-change="changePageNum"
            :current-page="page.pageNum"
            :page-sizes="[10, 20, 30, 40]"
            :page-size="page.pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="page.totalCount">
            </el-pagination>
        </div>
        <div class="hrm_module_con" v-show="talentStatus==4">
                <el-table
                :data="offerRecordsList4"
                border
                style="width: 100%">
                <el-table-column
                type="index"
                label="序号"
                width="55">
                </el-table-column>
                <el-table-column
                prop="name"
                label="姓名"
                width="180">
                </el-table-column>
                <el-table-column
                label="类型">
                    <template scope="scope">
                        <div v-if="scope.row.userDraw==1">正式</div>
                        <div v-if="scope.row.userDraw==2">试用</div>
                        <div v-if="scope.row.userDraw==3">兼职</div>
                        <div v-if="scope.row.userDraw==4">实习</div>
                        <div v-if="scope.row.userDraw==5">劳务派遣</div>
                    </template>
                </el-table-column>
                <el-table-column
                prop="deptName"
                label="部门">
                </el-table-column>
                <el-table-column
                prop="positionName"
                label="职位">
                </el-table-column>
                <el-table-column
                prop="phone"
                label="手机号">
                </el-table-column>
                <el-table-column
                prop="joinDate"
                label="原定到岗日期">
                </el-table-column>
                <el-table-column
                prop="reason"
                label="放弃原因">
                    <template scope="scope">
                        <span>{{scope.row.reason}}</span>
                        <el-popover
                        ref="popover1"
                        placement="top-end"
                        width="200"
                        trigger="hover">
                        {{scope.row.reasonRemark}}
                        </el-popover>
                        <i class="el-icon-information" v-popover:popover1></i>
                    </template>
                </el-table-column>
                <el-table-column
                label="操作">
                <template scope="scope">
                    <el-button  type="text" size="small" @click="resendOffer(scope.row)">重发offer</el-button>
                    <el-button type="text" size="small" @click="previewOffer(scope.row.offerId)">查看offer</el-button>
                </template>
                </el-table-column>
            </el-table>
            <el-pagination
            class="margin_t_20"
            @size-change="changePageSize"
            @current-change="changePageNum"
            :current-page="page.pageNum"
            :page-sizes="[10, 20, 30, 40]"
            :page-size="page.pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="page.totalCount">
            </el-pagination>
        </div>
        </div>
        <el-dialog
        title="查看offer"
        v-model="previewOfferShow"
        size="small">
        <span v-html="previewOfferText"></span>
        <dl v-if="previewOfferLink">
            <dt style="font-size:16px;font-weight:500px;">附件:</dt>
            <dd v-for="file in previewOfferLink"><i class="iconfont">&#xe63b;</i>{{file}}</dd>
        </dl>
        <span slot="footer" class="dialog-footer">
            <el-button @click="previewOfferShow = false">取 消</el-button>
            <el-button type="primary" @click="previewOfferShow = false">确 定</el-button>
        </span>
        </el-dialog>
        <el-dialog
        title="提示"
        v-model="giveupShow"
        size="tiny">
        <el-form ref="form" :model="giveupForm" label-width="80px">
            <el-form-item label="原因">
                <el-select v-model="giveupForm.quitReason" placeholder="请选择offer放弃原因">
                    <el-option :label="item.reason" :value="item.reason" v-for="item in noAcceptReasonList"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="备注">
                <el-input
                type="textarea"
                :autosize="{ minRows: 2, maxRows: 4}"
                placeholder="请输入放弃offer备注"
                v-model="giveupForm.reasonRemark">
                </el-input>
            </el-form-item>
        </el-form>
        <span slot="footer" class="dialog-footer">
            <el-button @click="giveupShow = false">取 消</el-button>
            <el-button type="primary" @click="offerRejected">确 定</el-button>
        </span>
        </el-dialog>
    </div>
</template>

<script>
    export default {
        name:'talentpool',
        data(){
            return{
                talentStatus:0,
                tableData0:[],
                tableData1:[],
                currentPage4:1,
                page:{
                    pageNum:1,
                    pageSize:10,
                    totalCount:0
                },
                offerRecordsCount0:0,
                offerRecordsList0:[],
                previewOfferText:'',
                previewOfferShow:false,
                offerRecordsCount1:0,
                offerRecordsCount2:0,
                offerRecordsCount3:0,
                offerRecordsCount4:0,
                offerRecordsList1:[],
                offerRecordsList2:[],
                offerRecordsList3:[],
                offerRecordsList4:[],
                noAcceptReasonList:[],
                giveupShow:false,
                giveupForm:{
                    quitReason:'',
                    reasonRemark:'',
                },
                offerId:'',//暂存offerId
                hireEmployerId:'',//暂存hireEmployerId员工id
                previewOfferLink:[],
            }
        },
        mounted(){
            this.hasSentOfferRecords();
            this.getNoAcceptReasonList();
            // this.awaitSentOfferRecords();
            // this.awaitReceiveOfferRecords();
            // this.awaitEntryOfferRecords();
            // this.abandaonOfferRecords();
            this.getcount();
        },
        methods:{
            showOffer(){//查看offer

            },
            changetalentStatus(v){
                var self=this;
                self.talentStatus=v;
                self.page={
                    pageNum:1,
                    pageSize:10,
                    totalCount:0
                };
                switch (self.talentStatus) {
                    case 0:
                        self.hasSentOfferRecords();
                        break;
                    case 1:
                        self.awaitSentOfferRecords();
                        break;
                    case 2:
                        self.awaitReceiveOfferRecords();
                        break;
                    case 3:
                        self.awaitEntryOfferRecords();
                        break;
                    case 4:
                        self.abandaonOfferRecords();
                        break;
                
                    default:
                        break;
                }
            },
            goOffer(row,chongfa){
                var self=this;
                if(chongfa=="chongfa"){
                    self.$router.push({name:'gooffer'});
                }else{
                    self.$router.push({name:"gooffer",params:{active:row.processStatus*1+1,hireEmployerId:row.hireEmployerId}})
                }  
            },
            deleOffer(row){
                var self=this;
                self.$confirm('此操作将永久删除该记录, 是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    var method="TalentPool/deleteAwaitSentOffer",
                        param=JSON.stringify({
                            offerId:row.offerId
                        }),
                        successd=function(res){
                            self.$message({
                                message:'删除成功!',
                                type:'success'
                            })
                            self.awaitSentOfferRecords();
                        };
                    self.$http(method,param,successd);
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消删除'
                    });          
                });
                
            },
            changePageSize(pageSize){
                var self = this;
                self.page.pageSize=pageSize;
                self.page.pageNum=1;
                switch (self.talentStatus) {
                    case 0:
                        self.hasSentOfferRecords();
                        break;
                    case 1:
                        self.awaitSentOfferRecords();
                        break;
                    case 2:
                        self.awaitReceiveOfferRecords();
                        break;
                    case 3:
                        self.awaitEntryOfferRecords();
                        break;
                    case 4:
                        self.abandaonOfferRecords();
                        break;
                
                    default:
                        break;
                }
            },
            changePageNum(pageNum){
                var self = this;
                self.page.pageNum=pageNum;
                switch (self.talentStatus) {
                    case 0:
                        self.hasSentOfferRecords();
                        break;
                    case 1:
                        self.awaitSentOfferRecords();
                        break;
                    case 2:
                        self.awaitReceiveOfferRecords();
                        break;
                    case 3:
                        self.awaitEntryOfferRecords();
                        break;
                    case 4:
                        self.abandaonOfferRecords();
                        break;
                
                    default:
                        break;
                }
            },
            hasSentOfferRecords(){//offer发放记录
                var self=this;
                var method="TalentPool/hasSentOfferRecords",
                    param=JSON.stringify({
                        pageNum:self.page.pageNum,
                        pageSize:self.page.pageSize
                    }),
                    successd=function(res){
                        console.log(res);
                        self.offerRecordsCount0=res.data.data.count;
                        self.page=res.data.data.page;
                        self.offerRecordsList0=res.data.data.awaitSentOfferRecords;
                    };
                self.$http(method,param,successd);
            },
            previewOffer(id){//查看offer
                var self=this;
                var method="TalentPool/previewOffer",
                    param=JSON.stringify({id:id}),
                    successd=function(res){
                        if(res.data.data.offerInfo){
                            self.previewOfferShow=true;
                            self.previewOfferText=res.data.data.offerInfo;
                            self.previewOfferLink=res.data.data.offerLink;
                        }else{
                            self.$message.error("没有offer内容!");
                        }
                    };
                self.$http(method,param,successd);
            },
            awaitSentOfferRecords(){//待发送offer
                var self=this;
                var method="TalentPool/awaitSentOfferRecords",
                    param=JSON.stringify({
                        pageNum:self.page.pageNum,
                        pageSize:self.page.pageSize
                    }),
                    successd=function(res){
                        console.log(res);
                        self.offerRecordsCount1=res.data.data.count;
                        self.page=res.data.data.page;
                        self.offerRecordsList1=res.data.data.awaitSentOfferRecords;
                    };
                self.$http(method,param,successd);
            },
            awaitReceiveOfferRecords(){//待接受offer
                var self=this;
                var method="TalentPool/awaitReceiveOfferRecords",
                    param=JSON.stringify({
                        pageNum:self.page.pageNum,
                        pageSize:self.page.pageSize
                    }),
                    successd=function(res){
                        console.log(res);
                        self.offerRecordsCount2=res.data.data.count;
                        self.page=res.data.data.page;
                        self.offerRecordsList2=res.data.data.awaitSentOfferRecords;
                    };
                self.$http(method,param,successd);
            },
            awaitEntryOfferRecords(){//待入职
                var self=this;
                var method="TalentPool/awaitEntryOfferRecords",
                    param=JSON.stringify({
                        pageNum:self.page.pageNum,
                        pageSize:self.page.pageSize
                    }),
                    successd=function(res){
                        console.log(res);
                        self.offerRecordsCount3=res.data.data.count;
                        self.page=res.data.data.page;
                        self.offerRecordsList3=res.data.data.awaitEntryOfferRecords;
                        self.offerRecordsList3.forEach(function(item){
                            item.proccessStatus=item.proccessStatus-3;
                            console.log(item);
                        });
                    };
                self.$http(method,param,successd);
            },
            abandaonOfferRecords(){//offer放弃记录
                var self=this;
                var method="TalentPool/abandaonOfferRecords",
                    param=JSON.stringify({
                        pageNum:self.page.pageNum,
                        pageSize:self.page.pageSize
                    }),
                    successd=function(res){
                        console.log(res);
                        self.offerRecordsCount4=res.data.data.count;
                        self.page=res.data.data.page;
                        self.offerRecordsList4=res.data.data.awaitEntryOfferRecords;
                    };
                self.$http(method,param,successd);
            },
            getNoAcceptReasonList(){
                var self=this;
                var method="noAcceptReason/getNoAcceptReasonList",
                    param=JSON.stringify({
                        pageSize:100,
                        pageNum:1
                    }),
                    successd=function(res){
                        self.noAcceptReasonList=res.data.data.list;
                    };
                self.$http(method,param,successd);
            },
            giveup(offerId){
                this.hireEmployerId=offerId;
                this.giveupShow=true;
            },
            offerRejected(){
                var self=this;
                var method="TalentPool/offerRejected",
                    param=JSON.stringify({
                        id:self.hireEmployerId,
                        quitReason:self.giveupForm.quitReason,
                        reasonRemark:self.giveupForm.reasonRemark
                    }),
                    successd=function(res){
                        self.giveupShow=false;
                        self.awaitEntryOfferRecords();
                        self.abandaonOfferRecords();
                        self.$message({
                            message:'操作成功',
                            type:'success'
                        });
                        self.awaitReceiveOfferRecords();
                    };
                self.$http(method,param,successd);
            },
            confirmJoin(row){
                console.log(row);
                this.$router.push({name:'confirmjoin',params:{hireEmployerId:row.hireEmployerId}});
            },
            resendOffer(row){
                var self=this;
                var method="sendOffer/resendOffer",
                    param=JSON.stringify({hireEmployerId:row.hireEmployerId}),
                    successd=function(res){
                        self.$router.push({name:"gooffer",params:{active:'2',hireEmployerId:row.hireEmployerId}})
                    };
                self.$http(method,param,successd);
            },
            getcount(){
                var self=this;
                var method="TalentPool/count",
                    param=JSON.stringify({}),
                    successd=function(res){
                        self.offerRecordsCount0=res.data.data.countList.count1;
                        self.offerRecordsCount1=res.data.data.countList.count2;
                        self.offerRecordsCount2=res.data.data.countList.count3;
                        self.offerRecordsCount3=res.data.data.countList.count4;
                        self.offerRecordsCount4=res.data.data.countList.count5;
                    };
                self.$http(method,param,successd);
            }
        },
    }
</script>

<style scoped>
    .talentpool_head_ul{width: 100%;cursor: pointer;}
    .talentpool_head_ul.active{color: #5aa2e7;}
    .talentpool_head_ul li{width: 100%;text-align: center;height: 30px;line-height: 30px;}
    .popover_ul{width: 200px;}
    .popover_dt div{width: 50px;height: 50px;background: #5aa2e7;color: #fff;border-radius: 50%;float: left;line-height: 50px;text-align:center;}
    .popover_dt h1{margin-left: 55px;display: block;padding-top: 10px;}
    .popover_dt h2{margin-left: 55px;}
    .popover_dd1{margin-top: 20px;margin-left: 30px;}
    .popover_dd2{margin-left: 20px;margin-top: 20px;}
</style>