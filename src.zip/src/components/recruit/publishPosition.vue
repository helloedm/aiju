<template>
  <div id="mainWrap">
      <ul>
          <li>
              <div class="title">个人信息</div>
              <el-form :model="recruitPosition" :rules="rules" ref="" label-width="100px" class="demo-ruleForm">
                    <el-row :gutter="20">
                        <el-col :span="8" :offset="2">
                            <el-form-item label="职位分类" prop="categoryId">
                                <el-select v-model="recruitPosition.categoryId">
                                    <el-option v-for="item in positionNameList" :label="item.name" :value="item.id" :key="item.id"></el-option>
                                </el-select>
                            </el-form-item>
                            <el-form-item label="职位名称" prop="positionName">
                                <el-input style="width: 194px;" v-model="recruitPosition.positionName"></el-input>
                            </el-form-item>
                            <el-form-item label="职位性质" prop="positionType">
                                <el-radio-group v-model="recruitPosition.positionType">
                                    <el-radio-button label="1">全职</el-radio-button>
                                    <el-radio-button label="2">兼职</el-radio-button>
                                    <el-radio-button label="3">实习</el-radio-button>
                                </el-radio-group>
                            </el-form-item>
                            <el-form-item label="职位类别" prop="classifyId">  
                                <el-cascader
                                    expand-trigger="hover"
                                    :options="classifyLists"
                                    v-model="recruitPosition.classifyIdArray">
                                </el-cascader>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8" :offset="2">
                            <el-form-item label="招聘人数" prop="posiNum">
                                <el-input style="width: 194px;" v-model="recruitPosition.posiNum"></el-input>
                            </el-form-item>
                            <el-form-item label="结束日期" prop="posiEndDate">
                                <el-date-picker
                                    v-model="recruitPosition.posiEndDate"
                                    type="date"
                                    placeholder="选择日期">
                                </el-date-picker>
                            </el-form-item>
                            <el-form-item label="工作城市" prop="workCity">
                                <el-cascader
                                    expand-trigger="hover"
                                    :options="workCityLists"
                                    v-model="recruitPosition.workCityArray"
                                    change-on-select>
                                </el-cascader>
                            </el-form-item>
                             <el-form-item label="工作地址">
                                <el-input style="width: 194px;" v-model="recruitPosition.workAddress"></el-input>
                            </el-form-item>
                             
                        </el-col>
                    </el-row>
            </el-form>
          </li>
          <li>
              <div class="title">职位要求</div>
              <el-form :model="recruitPosition"  ref="" label-width="100px" class="demo-ruleForm">
                    <el-row :gutter="20">
                        <el-col :span="8" :offset="2">
                            <el-form-item label="工作经验" prop="workYear">
                                <el-select v-model="recruitPosition.workYear">
                                    <el-option v-for="item in opt.workYear" :label="item.label" :value="item.value" :key="item.value"></el-option>
                                </el-select>
                        </el-form-item>
                            <el-form-item label="学历要求" prop="educationRequire">
                                <el-select v-model="recruitPosition.educationRequire">
                                    <el-option v-for="item in opt.education" :label="item.label" :value="item.value" :key="item.value"></el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8" :offset="2">
                            <el-form-item label="职位月薪" prop="positionSalary">
                                <el-input style="width: 95px;" placeholder="最低" v-model="recruitPosition.positionSalaryLowest">
                                    <template slot="append">k</template>
                                </el-input>
                                <el-input style="width: 95px;" placeholder="最高" v-model="recruitPosition.positionSalaryHighest">
                                    <template slot="append">k</template>
                                </el-input>
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row>
                         <el-col :span="8" :offset="2" style="margin-top: 20px;">
                               <el-form-item label="职位描述" prop="positionDesc">
                                    <el-input
                                        style="width: 635px; height: 80px;"
                                        type="textarea"
                                        :rows="4"
                                        placeholder="请输入内容"
                                        v-model="recruitPosition.positionDesc">
                                    </el-input>
                                </el-form-item>
                          </el-col>
                   </el-row>
            </el-form>
          </li>
          <li>
               <el-form :model="recruitPosition" :rules="rules" ref="" label-width="100px" class="demo-ruleForm">
                  <div class="title">其他要求</div>
                    <el-row>
                        <el-col :span="8" :offset="2" style="margin-top: 20px;">
                            <el-form-item label="接收简历邮箱" prop="receiveEmail" label-width="120px">
                                <el-input v-model="recruitPosition.receiveEmail" placeholder="请输入内容" :disabled="true">></el-input>
                            </el-form-item>
                        </el-col>
                    </el-row>
               </el-form>
          </li>
      </ul>
      <el-button style="margin: 20px 0 0 210px" type="primary" v-if="id == '-1'" @click="publish()">发布</el-button>
      <el-button style="margin: 20px 0 0 210px" type="primary" v-if="id != '-1'" @click="editSave()">保存修改</el-button>
  </div>
</template>
<script>

import allcity from '../../script/allcity';

export default {
  name: 'publishPosition',
  data(){
    return{
        id: '-1',
        recruitPosition: {
            categoryId: '',//职位分类id
            positionName: '',//职位名称
            positionType: '1',//职位性质 1:全职 2:兼职 3:实习
            classifyIdArray: [],//职位类别id
            classifyName: '',//职位类别名称
            posiNum: '',//招聘人数
            workCityArray: [],//工作城市
            posiEndDate: '',//职位截止日期
            workYear: '',//工作经验/工作年限 1:不限 2:应届毕业生 3:1年以下 4:1-3年 5:3-5年 6:5-10年 7:10年以上
            educationRequire: '',//学历要求 1:不限 2:大专以下 3:大专 4:本科 5:硕士 6:博士
            positionSalaryLowest: '',//职位最低月薪
            positionSalaryHighest: '',//职位最高月薪
            positionDesc: '',//职位描述
            receiveEmail: '',//接收简历邮箱,
            workAddress: ''
        },
           rules: {
            categoryId: [
                { required: true, message: '请选择职位分类', trigger: 'blur'}
            ],
            positionName: [
                { required: true, message: '请输入职位名称', trigger: 'blur'}
            ],
            positionType: [
                { required: true, message: '请选择职位性质', trigger: 'blur'}
            ],
            classifyId: [
                { required: true, message: '请选择职位类别', trigger: 'blur'}
            ],
            posiNum: [
                { required: true, message: '请输入招聘人数', trigger: 'blur'}
            ],
            posiEndDate: [
                { type: 'date', required: true, message: '请选择日期', trigger: 'change' }
            ],
            workCity:[
                { required: true, message: '请选择城市', trigger: 'blur'}
            ],
            workYear:[
                { required: true, message: '请选择工作年限', trigger: 'blur'}
            ],
            educationRequire:[
                { required: true, message: '请选择学历要求', trigger: 'blur'}
            ],
            positionSalary: [
                { required: false, message: '请输入月薪范围', trigger: 'blur'}
            ],
            positionDesc: [
                 { required: true, message: '请输入职位描述', trigger: 'blur'}
            ],
            receiveEmail: [
                 { required: true, message: '请输入邮箱', trigger: 'blur'}
            ]
        },
        positionNameList: [],//职位分类列表
        classifyList: [],//职位类别列表
     classifyLists:[],
     workCityLists: [],
     opt: {
        workYear:[
            {value: 1,label: '不限'},
            {value: 2,label: '应届'},
            {value: 3,label: '1年以下'},
            {value: 4,label: '1-3年'},
            {value: 5,label: '3-5年'},
            {value: 6,label: '5-10年'},
            {value: 7,label: '10年以上'},
        ],
        education:[
            {value: 1, label: '不限'},
            {value: 2, label: '大专以下'},
            {value: 3, label: '大专'},
            {value: 4, label: '本科'},
            {value: 5, label: '硕士'},
            {value: 6, label: '博士'},
        ]
     },
    }
  },
  methods: {
    init(){
        if(this.$route.query.id){
            this.id = this.$route.query.id;
            let methods = 'recruitPosition/getPositionDetail',
            self = this,
            param = JSON.stringify({
                id: this.id,
                type: '2'
            }),
            successd = function(res){
                self.recruitPosition = res.data.data;
                self.recruitPosition.posiEndDate = new Date(res.data.data.posiEndDate)
            }
            this.$http(methods, param, successd)
        }
    },
    empty(){
        this.recruitPosition = {
            categoryId: '',//职位分类id
            positionName: '',//职位名称
            positionType: '1',//职位性质 1:全职 2:兼职 3:实习
            classifyIdArray: [],//职位类别id
            classifyName: '',//职位类别名称
            posiNum: '',//招聘人数
            workCityArray: [],//工作城市
            posiEndDate: '',//职位截止日期
            workYear: '',//工作经验/工作年限 1:不限 2:应届毕业生 3:1年以下 4:1-3年 5:3-5年 6:5-10年 7:10年以上
            educationRequire: '',//学历要求 1:不限 2:大专以下 3:大专 4:本科 5:硕士 6:博士
            positionSalaryLowest: '',//职位最低月薪
            positionSalaryHighest: '',//职位最高月薪
            positionDesc: '',//职位描述
            receiveEmail: '',//接收简历邮箱,
            workAddress: ''
        }
    },
    getPositionCategoryList(){
      let methods = 'recruitPosition/getPositionCategoryList',
      param = JSON.stringify({}),
      self = this,
      successd = function(res){
        self.positionNameList = res.data.data;
      }
      this.$http(methods, param, successd)
    },
    getEmail(){
        let methods = 'recruitPosition/getAdminEamil',
        param = JSON.stringify({}),
        self = this,
        successd = function(res){
            self.recruitPosition.receiveEmail = res.data.data;
        }
        this.$http(methods, param, successd)
    },
    getPositionClassifyTree(){
      let methods = 'recruitPosition/getPositionClassifyTree',
      param = JSON.stringify({}),
      self = this,
      successd = function(res){
        self.classifyList = res.data.data;
        self.transitionClassifyLists()
      }
      this.$http(methods, param, successd)  
    },
    transitionCityLists(){
        let provinces = allcity.province,
        citys = allcity.city;
        for(let j = 0; j < provinces.length; j++) {
            let item = provinces[j]
            item.value = item.name
            item.label = item.name
            item.children = citys[item.id]
        }
        for(let k in citys) {
            let city = citys[k]
            for(let i = 0; i < city.length; i++) {
                let item = city[i]
                item.value = item.name
                item.label = item.name
            }
        }
        this.workCityLists = provinces;
    },
    transitionClassifyLists(){
        let obj = this.classifyList,
        opt = [];
        for(var i = 0; i < obj.length; i++){
            var o1 = [];
            o1.label = obj[i].name;
            o1.value = obj[i].id;
            o1.children = [];
            opt.push(o1);
            for(var j = 0; j < obj[i].childrens.length; j++){
                var o2 = [];
                o2.label = obj[i].childrens[j].name;
                o2.value = obj[i].childrens[j].id;
                o2.children = [];
                opt[i].children.push(o2)
                for(var k = 0; k < obj[i].childrens[j].childrens.length; k++){
                    var o3 = [];
                    o3.label = obj[i].childrens[j].childrens[k].name;
                    o3.value = obj[i].childrens[j].childrens[k].id;
                    opt[i].children[j].children.push(o3)
                }
            }
        }
        this.classifyLists = opt;
    },
    publish(){
      if(this.recruitPosition.classifyIdArray.length < 3){
           this.$message({
           message: '请选择职位类别',
           type: 'warning'
        });
        return
      }
      if(this.recruitPosition.workCityArray.length < 2){
           this.$message({
           message: '请选择城市',
           type: 'warning'
        });
        return
      }
      let methods = 'recruitPosition/publishNewPosition',
      self = this,
      param = JSON.stringify({
            recruitPosition: {
                categoryId: self.recruitPosition.categoryId,//职位分类id
                positionName: self.recruitPosition.positionName,//职位名称
                positionType: self.recruitPosition.positionType,//职位性质 1:全职 2:兼职 3:实习
                classifyIdArray: self.recruitPosition.classifyIdArray,//职位类别id
                posiNum: self.recruitPosition.posiNum,//招聘人数
                workCityArray: self.recruitPosition.workCityArray,//工作城市
                posiEndDate: self.$date(self.recruitPosition.posiEndDate),//职位截止日期
                workYear: self.recruitPosition.workYear,//工作经验/工作年限 1:不限 2:应届毕业生 3:1年以下 4:1-3年 5:3-5年 6:5-10年 7:10年以上
                educationRequire: self.recruitPosition.educationRequire,//学历要求 1:不限 2:大专以下 3:大专 4:本科 5:硕士 6:博士
                positionSalaryLowest: self.recruitPosition.positionSalaryLowest,//职位最低月薪
                positionSalaryHighest: self.recruitPosition.positionSalaryHighest,//职位最高月薪
                positionDesc: self.recruitPosition.positionDesc,//职位描述
                receiveEmail: self.recruitPosition.receiveEmail,//接收简历邮箱,
                workAddress: self.recruitPosition.workAddress
            }
      }),
      successd = function(res){
           self.$message({
                message: res.data.message,
                type: 'success'
            });
          self.empty();
      }
      this.$http(methods, param, successd)  
    },
    editSave(){
         if(this.recruitPosition.classifyIdArray.length < 3){
           this.$message({
           message: '请选择职位类别',
           type: 'warning'
        });
        return
      }
      if(this.recruitPosition.workCityArray.length < 2){
           this.$message({
           message: '请选择城市',
           type: 'warning'
        });
        return
      }
      let methods = 'recruitPosition/updatePosition',
      self = this,
      param = JSON.stringify({
            recruitPosition: {
                id: this.id,
                categoryId: self.recruitPosition.categoryId,//职位分类id
                positionName: self.recruitPosition.positionName,//职位名称
                positionType: self.recruitPosition.positionType,//职位性质 1:全职 2:兼职 3:实习
                classifyIdArray: self.recruitPosition.classifyIdArray,//职位类别id
                posiNum: self.recruitPosition.posiNum,//招聘人数
                workCityArray: self.recruitPosition.workCityArray,//工作城市
                posiEndDate: self.$date(self.recruitPosition.posiEndDate),//职位截止日期
                workYear: self.recruitPosition.workYear,//工作经验/工作年限 1:不限 2:应届毕业生 3:1年以下 4:1-3年 5:3-5年 6:5-10年 7:10年以上
                educationRequire: self.recruitPosition.educationRequire,//学历要求 1:不限 2:大专以下 3:大专 4:本科 5:硕士 6:博士
                positionSalaryLowest: self.recruitPosition.positionSalaryLowest,//职位最低月薪
                positionSalaryHighest: self.recruitPosition.positionSalaryHighest,//职位最高月薪
                positionDesc: self.recruitPosition.positionDesc,//职位描述
                receiveEmail: self.recruitPosition.receiveEmail,//接收简历邮箱,
                workAddress: self.recruitPosition.workAddress
            }
      }),
      successd = function(res){
            self.$message({
                message: '保存成功',
                type: 'success'
            });
          self.$router.push({path:'list'});
      }
      this.$http(methods, param, successd) 
    },
  },
  mounted(){
    this.getPositionClassifyTree()
    this.getPositionCategoryList()
    this.transitionCityLists()
    this.getEmail()
    this.init();
  }         
}
</script>
<style scoped>
 #mainWrap{
     background-color: #fff;
     padding: 20px;
 }
 li .el-row{
     margin: 20px 0;
 }
 .title{
    width:100%;
    height:18px; 
    font-size:18px;
    font-family:MicrosoftYaHei;
    color:rgba(31,45,61,1);
    line-height:14.399999999999999px;
    border-bottom: 1px solid #E9ECEF;
    padding-bottom: 15px;
 }
</style>


