<template>
  <div class="hrm_module">
      <div id="content" class="hrm_module_con">
        <div class="left_btn">
          <el-button :disabled="multipleSelection.length != 1" @click="edit()" type="primary">
           <i class="el-icon-edit"></i>
            <span>修改</span>
            </el-button>
          <el-button :disabled="multipleSelection.length == 0" @click="deleteBtn()" type="primary">
            <i class="el-icon-delete"></i>
            <span>删除</span>
          </el-button>
          <el-button type="text" class="gj_search" @click="gjSearchCon = !gjSearchCon">高级搜索<i class="el-icon-caret-bottom" :class="{'el-icon-caret-top':gjSearchCon}"></i></el-button>
          <!-- <el-input v-model="character"
            class="search_usercare"
            @keyup.enter.native="search()"
            @blur="search()" placeholder="输入工作年限、应聘职位、学历等搜索" icon="search"></el-input> -->
             <el-input placeholder="输入关键词"  v-model="character.value" style="width: 350px; float: right;">
                <el-select v-model="character.type" slot="prepend" @blur="search()"  placeholder="请选择" style="width: 105px;">
                    <el-option label="职位名称" value="1"></el-option>
                    <el-option label="创建人" value="2"></el-option>
                    <el-option label="职位分类" value="3"></el-option>
                </el-select>
                <el-button slot="append" icon="search"></el-button>
            </el-input>
        </div>

        <div class="hrm_module_search"  v-show="gjSearchCon">
          <el-form :model="recruitPosition" label-width="100px" class="clearfix">
            <el-form-item label="职位分类" prop="categoryId" style="display: inline-block; width: 300px; ">
                <el-select v-model="recruitPosition.positionName">
                    <el-option v-for="item in positionNameList" :label="item.name" :value="item.id" :key="item.id"></el-option>
                </el-select>
            </el-form-item>
               <el-form-item label="创建日期" prop="categoryId" style="display: inline-block;">
                <el-date-picker
                  v-model="recruitPosition.startDate"
                  type="date"
                  placeholder="选择日期">
                </el-date-picker>
                <el-date-picker
                  v-model="recruitPosition.endDate"
                  type="date"
                  placeholder="选择日期">
                </el-date-picker>
              </el-form-item>
              <el-form-item label="工作城市" prop="workCity">
                  <el-cascader
                      expand-trigger="hover"
                      :options="workCityLists"
                      v-model="recruitPosition.workCityArr"
                      change-on-select
                      @change="handleChange">
                  </el-cascader>
              </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="search">搜索</el-button>
              <el-button @click="resetAdvancedSearch">重置</el-button>
            </el-form-item>
          </el-form>
        </div>

        <el-table
          ref="multipleTable"
          :data="positionList"
          border
          tooltip-effect="dark"
          style="width: 100%"
          @selection-change="handleSelectionChange">
          <el-table-column
            type="selection"
            select="selectChange">
          </el-table-column>
          <el-table-column
            prop="positionName"
            label="职位名称">
             <template scope="scope">
              <a href="javascript:;" @click="getDetail(scope.row)">{{ scope.row.positionName }}</a>
            </template>
          </el-table-column>
           <el-table-column
            prop="updateDate"
            label="创建日期">
          </el-table-column>
           <el-table-column
            prop="posiEndDate"
            label="截止日期">
          </el-table-column>
          <el-table-column
            prop="categoryName"
            label="职位分类">
          </el-table-column>
          <el-table-column
            prop="creatorName"
            label="创建人">
          </el-table-column>
          <el-table-column
            prop="updateDate"
            label="更新日期">
          </el-table-column>
          <el-table-column
            prop="workCity"
            label="工作地点">
          </el-table-column>
           <el-table-column
            prop="yingPinNum"
            label="应聘人数">
             <template scope="scope">
              <a href="javascript:;" @click="jump(scope.row)">{{ scope.row.yingPinNum }}</a>
            </template>
          </el-table-column>
        </el-table>
        <el-pagination
          class="margin_t_20"
          @size-change="changePageSize"
          @current-change="changePageNum"
          :current-page="config.pageNum"
          :page-sizes="[10, 20, 30, 40]"
          :page-size="config.pageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="config.totalCount">
        </el-pagination>
      </div>
  </div>
</template>
<script>

import allcity from '../../script/allcity';

export default {
  name: 'publishList',
  data(){
    return{
        workCity: '',
         recruitPosition: {
           pageNum: '',	//是	int	页码
           pageSize: '',//	是	int	每页大小
           positionName: '',//	否	string	职位名称
           creatorName: '',//	否	string	职位创建人
           categoryId: '',//	否	int	职位分类id
           startDate: '',//	否	string	创建日期 起始时间
           endDate: ''	,//否	string	创建日期 结束时间
           workCity: '',//	否	string	工作城市,如：杭州
           workCityArr: [],
        },
        workCityLists: [],
        positionNameList: [],//职位名称
      gjSearchCon: false,
      config: {
        pageSize: 10,
        pageNum: 1,
        processStatus: '1',
        totalCount:0
      },
      character: {
        type: '1',
        value: ''
      },
      positionList: [],
      multipleSelection: [],
    }
  },
  methods: {
    transitionWork(){
        let provinces = allcity.province,
        citys = allcity.city;
        for(let j = 0; j < provinces.length; j++) {
            let item = provinces[j]
            item.value = item.name
            item.label = item.name
            item.children = citys[item.id]
        }
        for(let k in citys) {
            let city = citys[k]
            for(let i = 0; i < city.length; i++) {
                let item = city[i]
                item.value = item.name
                item.label = item.name
            }
        }
        this.workCityLists = provinces;
    },
    getDetail(row){
      this.$router.push({path:'detail', query: {id: row.id}});
    },
    jump(row){
      if(row.interviewerIds){
       this.$router.push({name:'newResume', query: {'interviewerIds': row.interviewerIds}});
      }
    },
    getPositionCategoryList(){
      let methods = 'recruitPosition/getPositionCategoryList',
      param = JSON.stringify({}),
      successd = function(res){
        this.positionNameList = res.data.data;
      }
      this.$http(methods, param, successd)
    },
    handleChange(val){
      this.recruitPosition.workCity = val[1];
    },
    edit(){
       let id = this.multipleSelection[0].id;
       this.$router.push({path:'post', query: { id: id }});
    },
    search(){
       this.recruitPosition.positionName = '';
       this.recruitPosition.creatorName = '';
       this.recruitPosition.categoryId = '';
       if(this.character.type == '1'){
         this.recruitPosition.positionName = this.character.value
       }else if(this.character.type == '2'){
         this.recruitPosition.creatorName = this.character.value
       }else if(this.character.type == '3'){
         this.recruitPosition.categoryId = this.character.value
       }else if(this.character.type == ''){
          // this.$message.error('请选择搜索类型');
       }
      let method = 'recruitPosition/getPositionListByCondition',
      self = this,
      param = JSON.stringify({
        pageSize: this.config.pageSize,
        pageNum: this.config.pageNum,
        positionName: this.recruitPosition.positionName,
        creatorName: this.recruitPosition.creatorName,
        categoryId: this.recruitPosition.categoryId,
        startDate: this.$date(this.recruitPosition.startDate),
        endDate: this.$date(this.recruitPosition.endDate),
        workCity: this.recruitPosition.workCity
      }),
      successd = function(res){
        self.positionList = res.data.data.positionList;
        self.config.totalCount = res.data.data.page.totalCount;
      }
      this.$http(method, param, successd);
    },
    deleteBtn() {
      let str = '';
      for(var i = 0; i < this.multipleSelection.length; i++){
        str += this.multipleSelection[i].id;
        str = this.multipleSelection.length-1 > i ? str + ',' : str;
      }
      let method = 'recruitPosition/batchDeletePosition',
      self = this,
      param = JSON.stringify({
        ids: str
      }),
      successd = function(res){
        self.search();
      }
      this.$http(method, param, successd);
    },
    handleSelectionChange(val) {
      this.multipleSelection = val;
    },
    changePageSize(pageSize){
      var self = this;
      self.config.pageSize=pageSize;
      self.config.pageNum=1;
      this.search();
    },
    changePageNum(pageNum){
        var self = this;
        self.config.pageNum=pageNum;
        this.search();
    },
    resetAdvancedSearch(){
      this.recruitPosition = {
           pageNum: '',	//是	int	页码
           pageSize: '',//	是	int	每页大小
           positionName: '',//	否	string	职位名称
           creatorName: '',//	否	string	职位创建人
           categoryId: '',//	否	int	职位分类id
           startDate: '',//	否	string	创建日期 起始时间
           endDate: ''	,//否	string	创建日期 结束时间
           workCity: '',//	否	string	工作城市,如：杭州
           workCityArr: [],
        }
    },
  },
  mounted(){
    this.getPositionCategoryList();
    this.transitionWork();
    this.search();
  }
}
</script>
<style scoped>
.el-form{
  padding: 10px 10px 15px;
  border: 1px solid #BFCBD9;
  margin-bottom: 20px;
}
.gj_search{
  float: right;
}
.left_btn{
  margin-bottom: 20px;
}
.el-input-group__prepend, .el-input-group--append .el-input__inner, .el-input-group__prepend{
  width: 90px;
}
</style>


