<template>
    <div id="nopower">

    </div>
</template>

<style>
    #nopower{
        height: 250px;width: 250px;margin: 0 auto;background: url(../../images/no_power.png) no-repeat center;
    }
</style>