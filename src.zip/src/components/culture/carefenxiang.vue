<template>
    <div>
        这是一个H5页面
    </div>
</template>

<script>
    
</script>

<style scoped>
    
</style>