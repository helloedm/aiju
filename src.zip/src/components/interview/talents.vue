<template>
  <div id="talents">
    <el-tabs v-model="activeName" @tab-click="handleClick(activeName)">
      <el-tab-pane label="新简历库" name="1">
        
      </el-tab-pane>
      <el-tab-pane label="备选库" name="2"></el-tab-pane>
      <el-tab-pane label="面试库" name="3"></el-tab-pane>
      <!-- <el-tab-pane label="录用库" name="4"></el-tab-pane> -->
      <el-tab-pane label="企业人才库" name="5"></el-tab-pane>
    </el-tabs>
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name:'talents',
  data(){
    return{
      activeName:'1'
    }
  },
  mounted(){
    this.index()
  },
  methods:{
    index(){
      var self=this;
      console.log(this.$route.name)
      switch (self.$route.name) {
        case "newResume":
          self.activeName='1';
          break;
        case "alternative":
          self.activeName='2';
          break;
        case "library":
          self.activeName='3';
          break;
        case "enterprise":
          self.activeName='5';
          break;
        default:
          break;
      }
    },
    handleClick(name){
      var self=this;
      switch (name) {
        case '1':
          self.$router.push("/manage/talents/newResume")
          break;
        case '2':
          self.$router.push("/manage/talents/alternative");
          break;
        case"3":
          self.$router.push({name:'library'});
          break;
        case '4':
          self.$router.push({name:'hire'});
          break;
        case '5':
          self.$router.push({name:'enterprise'});
          break;
        default:
          break;
      }
    }
  }
}
</script>
<style scoped>

</style>


