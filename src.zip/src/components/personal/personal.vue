<template>
    <div id="personal">
        <header class="clearfix">
            <div v-if="form.userHeadImg == null" class="touxiang touxiang_name">{{form.name}}</div>
            <img :src="form.userHeadImg" alt="头像" class="touxiang" v-if="form.userHeadImg != null">
            <dl class="right">
                <dt>
                    <p class="personal_name"><span style="height:28px">{{form.name}}</span><el-button class="revamp" @click="changeHeadImg"icon="edit">修改头像</el-button></p>
                    <p class="personal_post"><i class="iconfont" :class="{'ff9948':form.userNature ==1}">&#xe608;&nbsp;&nbsp;</i><span>{{form.userNature ==1?"管理员":"普通用户"}}</span><a href="javascript:void(0);" v-if="form.userNature ==1" @click="renewal">续费</a></p>
                </dt>
                <dd>
                    <el-tabs v-model="activeName" @tab-click="handleClick">
                        <el-tab-pane label="个人中心" name="first">
                            <!--个人中心-->
                            <div class="hrm_module">
                                <div class="hrm_module_con" style="overflow:hidden;">
                            <el-form ref="form" :model="form" label-width="100px">
                                <el-form-item label="昵称" class="personal_left">
                                    <el-input v-model="form.name" disabled></el-input>
                                </el-form-item>
                                <el-form-item label="真实姓名" class="personal_right">
                                    <el-input v-model="form.realname" disabled></el-input>
                                </el-form-item>
                                 <el-form-item label="手机" class="personal_left">
                                    <el-input v-model="form.phone" disabled></el-input>
                                </el-form-item>
                                 <el-form-item label="密码" class="personal_right">
                                    <el-button @click="dialogFormVisible = true">修改密码</el-button>
                                </el-form-item>
                                 <el-form-item label="性别" class="personal_left">
                                    <el-input v-model="form.sexName" disabled></el-input>
                                </el-form-item>
                                 <el-form-item label="公司" class="personal_right">
                                    <el-input v-model="form.companyName" disabled></el-input>
                                </el-form-item>
                                 <el-form-item label="部门" class="personal_left">
                                    <el-input v-model="form.deptName" disabled></el-input>
                                </el-form-item>
                                 <el-form-item label="职位" class="personal_right">
                                    <el-input v-model="form.positionName" disabled></el-input>
                                </el-form-item>
                                 <el-form-item label="角色" class="personal_left">
                                    <el-input v-model="form.userRoles" disabled></el-input>
                                </el-form-item>
                                 <el-form-item label="工号" class="personal_right">
                                    <el-input v-model="form.userNo" disabled></el-input>
                                </el-form-item>
                                 <el-form-item label="出生日期" class="personal_left">
                                    <el-input v-model="form.birdthDay" disabled></el-input>
                                </el-form-item>
                                 <el-form-item label="入职日期" class="personal_right">
                                    <el-input v-model="form.joinDate" disabled></el-input>
                                </el-form-item>
                                 <el-form-item label="邮箱" class="personal_left">
                                    <el-input v-model="form.email" disabled></el-input>
                                </el-form-item>
                            </el-form>
                            </div></div>
                        </el-tab-pane>
                        <el-tab-pane label="用户信息" name="second" v-if="form.userNature ==1">
                            <!--用户信息-->
                            <div class="hrm_module">
                                <ul class="hrm_module_con userinfo_ul">
                                    <li class="userinfo">
                                        <i class="iconfont">&#xe698;</i>
                                        <h3>公司名</h3>
                                        <p>{{userInfo.companyName}}</p>
                                    </li>
                                    <li class="userinfo">
                                        <i class="iconfont">&#xe609;</i>
                                        <h3>用户类型</h3>
                                        <p>{{userInfo.userType}}</p>
                                    </li>
                                    <li class="userinfo">
                                        <i class="iconfont">&#xe64b;</i>
                                        <h3>到期时间</h3>
                                        <p>{{userInfo.expirationDate}}</p>
                                    </li>
                                    <li class="userinfo">
                                        <i class="iconfont">&#xe610;</i>
                                        <h3>收货地址</h3>
                                        <p v-if="userInfo.userAdress != ''">{{userInfo.userAdress}}</p>
                                        <p v-if="userInfo.userAdress == ''" class="addUserAdress" @click="addUserAdress">添加地址</p>
                                    </li>
                                </ul>
                            </div>
                        </el-tab-pane>
                        <el-tab-pane label="我的订单" name="third" v-if="form.userNature ==1">
                            <!--我的订单-->
                            <div class="hrm_module">
                                <div class="hrm_module_con">
                             <el-table
                            :data="tableData"
                            border>
                            <el-table-column
                                prop="ind"
                                label="序号"
                                width="50">
                            </el-table-column>
                            <el-table-column
                                prop="oid"
                                label="服务编号"
                                width="182">
                            </el-table-column>
                            <el-table-column
                                prop="title"
                                label="服务名称"
                                width="100">
                            </el-table-column>
                            <el-table-column
                                prop="servicePoint"
                                label="服务点"
                                width="160">
                            </el-table-column>
                            <el-table-column
                                prop="period"
                                label="有效期"
                                width="100">
                            </el-table-column>
                            <el-table-column
                                prop="gmtCreate"
                                label="购买时间">
                            </el-table-column>
                            <el-table-column
                                prop="price"
                                label="金额"
                                width="100">
                            </el-table-column>
                            <el-table-column
                                label="状态"
                                width="100">
                            <template scope="scope">
                                <el-button type="text" size="small" v-if="scope.row.status == '1'">已支付</el-button>
                                <el-button type="text" size="small" @click="ContinueToPay(scope.row.oid)" v-if="scope.row.status == '0'">继续支付</el-button>
                            </template>
                            </el-table-column>
                            </el-table>
                                <!--<el-pagination
                                @size-change="handleSizeChange"
                                @current-change="handleCurrentChange"
                                :current-page="currentPage4"
                                :page-sizes="[100, 200, 300, 400]"
                                :page-size="100"
                                layout="total, sizes, prev, pager, next, jumper"
                                :total="400"
                                class="personal_page"
                                >
                                </el-pagination>-->
                            </div>
                            </div>
                        </el-tab-pane>
                        <my-upload field="img"
                            @crop-success="cropSuccess"
                            @crop-upload-success="cropUploadSuccess"
                            @crop-upload-fail="cropUploadFail"
                            v-model="show"
                            :url="imgUpload"
                            :width="100"
                            :height="100"
                            :params="params"
                            :headers="headers"
                            img-format="png"></my-upload>
                    </el-tabs>
                </dd>
            </dl>
        </header>
        <!--修改密码-->
        <el-dialog title="修改密码" :visible.sync="dialogFormVisible" v-model="dialogFormVisible" size="tiny">
        <el-form :model="password" :rules="rulesPass" ref="password">
            <el-form-item label="旧密码" :label-width="formLabelWidth" prop="oldPass" >
                <el-input type="password" v-model="password.oldPass" auto-complete="off"></el-input>
            </el-form-item>
            <el-form-item label="新密码" :label-width="formLabelWidth" prop="pass" required>
                <el-input type="password" v-model="password.pass" auto-complete="off"></el-input>
            </el-form-item>
            <el-form-item label="确认新密码" :label-width="formLabelWidth" prop="checkPass" required>
                <el-input type="password" v-model="password.checkPass" auto-complete="off"></el-input>
            </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
            <el-button @click="dialogFormVisible = false">取 消</el-button>
            <el-button type="primary" @click="uploadPassword('password')">确 定</el-button>
        </div>
        </el-dialog>
        <!--新增地址-->
        <el-dialog title="新增地址" v-model="addAdressDialog" size="">
        <el-form :model="addAdress" :rules="rules" label-position="top" ref="addAdress">
            <el-form-item label="收货地址" label-width="120px" required>
                <el-col :span="8">
                    <el-form-item prop="province">
                         <el-select v-model="addAdress.province" placeholder="请选择" @change="changeProvince">
                            <el-option
                            v-for="item in provinceArr"
                            :label="item.name"
                            :value="item.id">
                            </el-option>
                        </el-select>
                    </el-form-item>
                </el-col>
                <el-col :span="8">
                    <el-form-item prop="city">
                        <el-select v-model="addAdress.city" placeholder="请选择" @change="changeCity">
                            <el-option
                            v-for="item in cityArr"
                            :label="item.name"
                            :value="item.id">
                            </el-option>
                        </el-select>
                    </el-form-item>
                </el-col>
                <el-col :span="8">
                    <el-form-item>
                         <el-select v-model="addAdress.district" placeholder="请选择">
                            <el-option
                            v-for="item in districtArr"
                            :label="item.name"
                            :value="item.id">
                            </el-option>
                        </el-select>
                    </el-form-item>
                </el-col>
            </el-form-item>
            <el-form-item label="具体地址" label-width="120px" prop="specificAddress">
                <el-input v-model="addAdress.specificAddress" auto-complete="off"></el-input>
            </el-form-item>
            <el-form-item label="收货人姓名" label-width="120px" prop="consigneeName">
                <el-input v-model="addAdress.consigneeName" auto-complete="off"></el-input>
            </el-form-item>
             <el-form-item label="收货人联系号码" label-width="120px" prop="consigneePhone">
                <el-input v-model="addAdress.consigneePhone" auto-complete="off"></el-input>
            </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
            <el-button @click="addAdressDialog = false">取 消</el-button>
            <el-button type="primary" @click="addAdressSubmit('addAdress')">确 定</el-button>
        </div>
        </el-dialog>
    </div>
</template>

<script>
import allcity from '../../script/allcity.js';
// import 'babel-polyfill'; // es6 shim
import myUpload from 'vue-image-crop-upload/upload-2.vue';
import Util from '../../script/util.js';
import md5 from 'js-md5';
    export default{
        name:'personal',
        data(){
             var validatePass = (rule, value, callback) => {
                if (value === '') {
                callback(new Error('请输入密码'));
                } else {
                if (this.password.checkPass !== '') {
                    this.$refs.password.validateField('checkPass');
                }
                callback();
                }
            };
            var validatePass2 = (rule, value, callback) => {
                if (value === '') {
                callback(new Error('请再次输入密码'));
                } else if (value !== this.password.pass) {
                callback(new Error('两次输入密码不一致!'));
                } else {
                callback();
                }
            };
            return{
                activeName:"first",
                form:{},
                dialogFormVisible:false,
                password:{
                    oldPass:'',
                    pass:'',
                    checkPass:''
                },
                formLabelWidth:'100px',
                tableData:[],
                userInfo:{},
                provinceArr:allcity.province,
                districtArr:[],
                cityArr:[],
                addAdressDialog:false,
               addAdress:{
                     province:'',
                    city:'',
                    district:'',
                    specificAddress:'',
                    consigneeName:'',
                    consigneePhone:'',
               },
                rules: {
                    province: [
                        {type:'number', required: true, message: '请选择省', trigger: 'change' }
                    ],
                    city: [
                        {type:'number', required: true, message: '请选择市', trigger: 'change' }
                    ],
                    specificAddress: [
                        { required: true, message: '请输入具体地址', trigger: 'blur' }
                    ],
                    consigneeName: [
                        { required: true, message: '请输入收货人姓名', trigger: 'blur' }
                    ],
                    consigneePhone: [
                        {required: true, message: '请输入收货人联系方式', trigger: 'blur' }
                    ]
                },
                 rulesPass: {
                    pass: [
                        { validator: validatePass, trigger: 'blur' }
                    ],
                    checkPass: [
                        { validator: validatePass2, trigger: 'blur' }
                    ],
                    oldPass: [
                        { required: true, message: '请输入旧密码', trigger: 'blur' }
                    ]
                },
                show: false,
                params: {},
                headers: {
                },
                imgDataUrl: '', // the datebase64 url of created image
                imgUpload:Util.imgUploadURL
            }
        },
        components:{
            'my-upload': myUpload
        },
        mounted(){
            this.getUserInfo();
            this.getBuyUserInfo();
            this.getAdress();
            this.getMyOrder();
            // this.demo();
        },
        methods:{
            handleClick(){

            },
            demo(){
                var params = new URLSearchParams();
                params.append("param",JSON.stringify({"aaa":"@ASD#$%^"}));
                this.$ajax({
                    method: 'post',
                    url: Util.url +'?method=buy/addDeliveryAddress',
                    data: params
                }).then(function (res) {
                    console.log(res);
                    
                }).catch(function(params) {
                    console.log(params);
                })
                // this.$ajax.post(Util.url+'?method=buy/addDeliveryAddress',{
                //     param:'1!@#$%^&*12321$%^&'
                // }).then(function(params) {
                    
                // })
            },
            getUserInfo(){
                var self = this;
                var method = "user/getUser";
                var param=JSON.stringify({});
                var successd = function(res) {
                    self.form = res.data.data;
                    if(self.form.birdthDay){
                        self.form.birdthDay=self.form.birdthDay.slice(0,10);
                    }
                    if(self.form.joinDate){
                        self.form.joinDate=self.form.joinDate.slice(0,10);
                    }
                    if(self.form.fileInfo == null){
                        var param = JSON.stringify({
                                fileId:"",
                                companyId:self.form.companyId,
                                userId:self.form.id,
                            })
                        self.params = {
                            param:JSON.stringify({
                                fileId:"",
                                companyId:self.form.companyId,
                                userId:self.form.id,
                            })
                        }
                    }else{
                        var param = JSON.stringify({
                                fileId:self.form.fileInfo.id,
                                companyId:self.form.companyId,
                                userId:self.form.id,
                            })
                        
                    }
                    self.params = {
                        "param":param,
                        "sign":md5('method' + "fileUpload/uploadUserHeadImg" + "param" + param + "ecbao")
                    }
                };
                self.$http(method,param,successd);
            },
            getBuyUserInfo(){
                var self = this;
                var method = "buy/userInfo",
                    param = JSON.stringify({}),
                    successd = function (res) {
                        self.userInfo = res.data.data;
                    };
                self.$http(method,param,successd)
            },
            addUserAdress(){
                this.addAdressDialog = true;
            },
            getAdress(){
                // this.$ajsx.jsonp("//hr.ecbao.cn/work/node_modules/angular/allcity.js",{jsonp:"cb"}).then(function (res) {
                //     console.log(res);
                // })
                console.log(allcity);
            },
            changeProvince(){
                this.cityArr = allcity.city[this.addAdress.province];
                this.addAdress.city="";
            },
            changeCity(){
                this.districtArr = allcity.district[this.addAdress.city];
                this.addAdress.district = "";
            },
            addAdressSubmit(formName) {
                var self = this;
                //获取地址对应的名字
                 for (var i = 0; i < self.provinceArr.length; i++) {
                    if(self.addAdress.province == self.provinceArr[i].id){
                       var province = self.provinceArr[i]['name'];
                    }
                }
                for (var i = 0; i < self.cityArr.length; i++) {
                    if(self.addAdress.city == self.cityArr[i].id){
                       var city = self.cityArr[i]['name'];
                    }
                }
                for (var i = 0; i < self.districtArr.length; i++) {
                    if(self.addAdress.district == self.districtArr[i].id){
                       var district = self.districtArr[i]['name'];
                    }
                }
                self.$refs[formName].validate((valid) => {
                if (valid) {
                    var method = "buy/addDeliveryAddress";
                    var param = JSON.stringify({
                        region:province + city + district,
                        address:self.addAdress.specificAddress,
                        contact:self.addAdress.consigneeName,
                        contactPhone:self.addAdress.consigneePhone
                    });
                    var successd = function(res) {
                        self.addAdressDialog = false;
                        self.getBuyUserInfo();
                    }
                    self.$http(method,param,successd);
                } else {
                    console.log('error submit!!');
                    return false;
                }
                });
            },
            uploadPassword(formName){
                var self = this;
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        var method = "user/updateLoginUserPwd";
                        var param = JSON.stringify({
                            oldPassword:self.password.oldPass,
                            newPassword:self.password.pass
                        });
                        var successd = function(res) {
                            self.dialogFormVisible = false;
                            self.$message({
                                message: res.data.message,
                                type: 'success'
                            });
                            top.location.href = "https://hr.ecbao.cn/login";
                        }
                        self.$http(method,param,successd);
                    } else {
                        console.log('error submit!!');
                        return false;
                    }
                });
            },
            getMyOrder(){
                var self = this;
                var method = "buy/myOrder";
                var param = JSON.stringify({});
                var successd = function (res) {
                    self.tableData = res.data.data.orders;
                    for(var i = 0;i<self.tableData.length;i++){
                        self.tableData[i].servicePoint = res.data.data.servicePoint;
                        self.tableData[i].ind = i+1;
                        self.tableData[i].period = res.data.data.orders[i].period+"个月";
                    }
                }
                self.$http(method,param,successd);
            },
            ContinueToPay(oid){
                location.href = "http://oa.ecbao.cn/dsb/GoPay?oid="+oid;
            },
            renewal(){
                location.href = "https://hr.ecbao.cn/price/"
            },
            changeHeadImg() {
				this.show = !this.show;
			},
            /**
			 * crop success
			 *
			 * [param] imgDataUrl
			 * [param] field
			 */
			cropSuccess(imgDataUrl, field){
                var self = this;
                // if(this.form.fileInfo == null){
                //     params =
                //         "method="+"fileUpload/insertFileRecord"
                //         +"&companyId="+self.form.companyId
                //         +"&userId="+self.form.id
                //         +"&oper="+"add"
                //         +"&fileId=''"
                //         +"&imgStr="+imgDataUrl;
                // }else{
                //     params = 
                //         "method="+"fileUpload/insertFileRecord"
                //         +"&companyId="+self.form.companyId
                //         +"&userId="+self.form.id
                //         +"&oper="+"update"
                //         +"&fileId="+self.form.fileInfo.id
                //         +"&imgStr="+imgDataUrl;
                // }
                // var successd = function(params) {
                //     location.reload();
                // }
                // self.$imgUpload(params,successd);
                if(self.form.fileInfo == null){
                    self.params = {
                        param:JSON.stringify({
                            fileId:"",
                            companyId:self.form.companyId,
                            userId:self.form.id,
                        })
                    }
                }else{
                    self.params = {
                         param:JSON.stringify({
                            fileId:self.form.fileInfo.id,
                            companyId:self.form.companyId,
                            userId:self.form.id,
                        })
                    }
                }
                console.log(self.params.param);
			},
			/**
			 * upload success
			 *
			 * [param] jsonData   服务器返回数据，已进行json转码
			 * [param] field
			 */
			cropUploadSuccess(jsonData, field){
                location.reload();
				// console.log('-------- upload success --------');
				// console.log(jsonData);
				// console.log('field: ' + field);
                // this.show = false;
                // location.reload();
			},
			/**
			 * upload fail
			 *
			 * [param] status    server api return error status, like 500
			 * [param] field
			 */
			cropUploadFail(status, field){
                location.reload();
				// console.log('-------- upload fail --------');
				// console.log(status);
				// console.log('field: ' + field);
			}
        }
    }
</script>

<style>
#personal{width: 1000px;margin: 0 auto;}
#personal .touxiang{width: 125px;height: 125px;float: left;line-height: 125px;}
#personal .touxiang_name{width: 125px;height: 125px;float: left;line-height: 125px;text-align: center;background-color: #62a8ea;color: #fff;font-size: 36px;overflow: hidden;z-index: 999;}
#personal .right dt{margin-left: 150px;height: 145px;}
/*#personal .el-tabs__nav{margin-left: 25px;}z*/
/*#personal .el-form{margin-top: 40px;}*/
#personal .personal_right{width: 400px;margin-left: 420px;height: 36px;}
#personal .personal_left{float: left;height: 36px;width: 400px;}
#personal .personal_name{font-size: 24px;position: relative;}
#personal .personal_name .revamp{position: absolute;right:0;}
.personal_post{font-size: 14px;margin-top: 20px;color: #bfcbd9;}
.personal_post a{margin-left: 20px;}
#personal .el-table__body-wrapper{overflow:inherit;}
#personal .personal_page{margin-top: 20px;}
#personal .userinfo_ul{margin-left: 125px;overflow: hidden;}
#personal .userinfo{width: 280px;float: left;margin: 25px 0;}
.userinfo i.iconfont{width: 40px;height: 40px;float: left;font-size: 36px;color: #bfcbd9;}
.userinfo h3{color: #bfcbd9;font-size: 14px;margin-left: 55px;height: 20px;vertical-align: top;font-weight: 400;}
.userinfo p{color: #333;font-size: 14px;margin-left: 55px;height: 20px;vertical-align: bottom;}
.ff9948{color: #ff9948;}
.userinfo .addUserAdress{color: #5aa2e7;cursor:pointer;}
#personal .el-table .cell{padding: 0 10px !important;}

</style>